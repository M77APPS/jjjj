package com.example.database

import androidx.room.*

@Dao
interface LinkDao {

    @Query("SELECT * FROM LinkSignature WHERE :url LIKE '%' || urlPattern || '%'")
    suspend fun findMatchingSignatures(url: String): List<LinkSignature>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(signatures: List<LinkSignature>)

    @Query("DELETE FROM LinkSignature WHERE addedDate < :timestamp")
    suspend fun deleteOlderThan(timestamp: Long)

    @Query("SELECT COUNT(*) FROM LinkSignature")
    suspend fun getSignaturesCount(): Int

    @Query("DELETE FROM LinkSignature")
    suspend fun clearSignatures()
}
