package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DeveloperThoughtsContent(context: Context) {
    val neonGreen = Color(0xFF00FF41)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    val quotes = remember {
        listOf(
            "المحترفون يبنون أدواتهم، والهواة يستخدمون أدوات الآخرين.",
            "الخصوصية ليست خياراً، بل هي الحصن الوحيد الباقي لكل عائلة وكل فرد.",
            "برمجة الحماية فن، وهندسة الاختراق إدراك عميق ومتبادل لأسرار هذا الفن.",
            "إذا كنت تعتقد أن التشفير يحل جميع مشاكلك الأمنية، فأنت لا تفهم المشكلة ولا تفهم الحل.",
            "الدرع الصامت لا يعلن عن نفسه بضجيج؛ الحماية الحقيقية تعمل بذكاء وتمنع الكارثة قبل وقوعها.",
            "لا تثق أبداً بمدخل غير مفحوص، فكل ثغرة في جدار الخصوصية تبدأ برابط منسي."
        )
    }

    var selectedQuoteIndex by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Card with neon styling
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, neonGreen.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Thoughts logo",
                    tint = neonGreen,
                    modifier = Modifier.size(36.dp)
                )

                Text(
                    text = "فكر وفلسفة المطور حمو الإلكتروني",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Divider(color = glassBorder)

                // The active displayed Quote
                Text(
                    text = "“${quotes[selectedQuoteIndex]}”",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = neonCyan,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Button(
                    onClick = {
                        selectedQuoteIndex = (selectedQuoteIndex + 1) % quotes.size
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, neonGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "الحصول على فكرة أمنية تالية 🧠",
                        color = neonGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Philosophy description
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "رؤية المهندس محمد حسام (حمو):",
                    color = neonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                Text(
                    text = "عندما تبني حلولك الأمنية بنفسك، فإنك لا تكتب برمجيات فقط؛ أنت تؤسس لحالة من الاكتفاء الرقمي والوعي الرفيع. إن هذا التطبيق صُنع بالكامل ليمثل خط مواجهة أول مستقل وخفيف جداً، صُمم لحماية المجتمع العربي من شفرات وسيرفرات الاختراق وهجمات التصيد غير المتمرسة.",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    textAlign = TextAlign.Justify
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Small decorative signature footer
        Text(
            text = "حمو الإلكتروني | خبير أمان معتمد | حماية بلا حدود",
            color = Color.Gray.copy(alpha = 0.8f),
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 14.dp)
        )
    }
}
