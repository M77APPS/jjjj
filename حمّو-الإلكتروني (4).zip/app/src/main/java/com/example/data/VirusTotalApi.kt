package com.example.data

import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path

@Serializable
data class VirusTotalResponse(
    val data: VirusTotalData? = null
)

@Serializable
data class VirusTotalData(
    val id: String,
    val type: String,
    val attributes: VirusTotalAttributes? = null
)

@Serializable
data class VirusTotalAttributes(
    val last_analysis_stats: AnalysisStats? = null,
    val last_analysis_results: Map<String, AnalysisResult>? = null
)

@Serializable
data class AnalysisStats(
    val harmless: Int = 0,
    val malicious: Int = 0,
    val suspicious: Int = 0,
    val undetected: Int = 0,
    val timeout: Int = 0
)

@Serializable
data class AnalysisResult(
    val category: String,
    val engine_name: String,
    val result: String,
    val method: String
)

interface VirusTotalApi {
    @GET("api/v3/urls/{id}")
    suspend fun getUrlReport(
        @Header("x-apikey") apiKey: String,
        @Path("id") urlId: String
    ): VirusTotalResponse
}
