package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "threat_logs")
data class ThreatLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String = "",
    val threatType: String = "SAFE",
    val actionTaken: String = "تم السماح بالمرور",
    val timestamp: Long = System.currentTimeMillis(),
    val securityScore: Int = 100,
    val riskType: String = "",
    val threatCategory: String = "",
    val analysisLog: String = ""
)
