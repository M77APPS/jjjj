package com.example.utils

import android.util.Base64
import java.security.spec.KeySpec
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object CryptoUtils {
    private const val ALGORITHM = "AES/GCM/NoPadding"
    private const val KEY_DERIVATION_ALGORITHM = "PBKDF2WithHmacSHA256"
    private val SALT = byteArrayOf(0x4a, 0x6d, 0x1c, 0x79, 0x2e, 0x6b, 0x14, 0x0f)
    private const val ITERATIONS = 1000
    private const val KEY_LENGTH = 256
    private const val GCM_IV_LENGTH = 12

    private fun deriveKey(passphrase: String): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM)
        val spec: KeySpec = PBEKeySpec(passphrase.toCharArray(), SALT, ITERATIONS, KEY_LENGTH)
        val tmp = factory.generateSecret(spec)
        return SecretKeySpec(tmp.encoded, "AES")
    }

    fun encrypt(plainText: String, passphrase: String): String {
        if (plainText.isEmpty() || passphrase.isEmpty()) return ""
        return try {
            val secretKey = deriveKey(passphrase)
            val cipher = Cipher.getInstance(ALGORITHM)
            
            val iv = ByteArray(GCM_IV_LENGTH)
            val secureRandom = java.security.SecureRandom()
            secureRandom.nextBytes(iv)

            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)
            val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

            val combined = ByteArray(iv.size + cipherText.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherText, 0, combined, iv.size, cipherText.size)

            Base64.encodeToString(combined, Base64.DEFAULT)
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    fun decrypt(encryptedTextBase64: String, passphrase: String): String {
        if (encryptedTextBase64.isEmpty() || passphrase.isEmpty()) return ""
        return try {
            val secretKey = deriveKey(passphrase)
            val combined = Base64.decode(encryptedTextBase64, Base64.DEFAULT)

            val iv = ByteArray(GCM_IV_LENGTH)
            System.arraycopy(combined, 0, iv, 0, iv.size)

            val cipherTextSize = combined.size - GCM_IV_LENGTH
            val cipherText = ByteArray(cipherTextSize)
            System.arraycopy(combined, GCM_IV_LENGTH, cipherText, 0, cipherTextSize)

            val cipher = Cipher.getInstance(ALGORITHM)
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(cipherText)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: java.security.GeneralSecurityException) {
            "AUTHENTICATION_ERR"
        } catch (e: Exception) {
            e.printStackTrace()
            "DECRYPTION_ERR"
        }
    }
}
