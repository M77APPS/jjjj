package com.example.utils

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object SecurityEventBus {
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 100)
    val events: SharedFlow<String> = _events.asSharedFlow()

    fun emitEvent(message: String) {
        _events.tryEmit("⚡ [${currentTimeString()}] $message")
    }

    private fun currentTimeString(): String {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        return sdf.format(java.util.Date())
    }
}
