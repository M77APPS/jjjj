package com.example.analysis

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import java.security.MessageDigest

object AppIntegrityChecker {
    private const val TAG = "AppIntegrityChecker"

    fun getAppSignatureSHA256(context: Context): String {
        try {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val packageInfo = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = packageInfo.signingInfo
                val signatures = signingInfo?.signingCertificateHistory ?: signingInfo?.apkContentsSigners
                if (signatures != null && signatures.isNotEmpty()) {
                    val digest = MessageDigest.getInstance("SHA-256")
                    val certBytes = signatures[0].toByteArray()
                    val sha256Bytes = digest.digest(certBytes)
                    return sha256Bytes.joinToString("") { "%02X".format(it) }
                }
            } else {
                @Suppress("DEPRECATION")
                val packageInfo = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
                @Suppress("DEPRECATION")
                val signatures = packageInfo.signatures
                if (signatures != null && signatures.isNotEmpty()) {
                    val digest = MessageDigest.getInstance("SHA-256")
                    val certBytes = signatures[0].toByteArray()
                    val sha256Bytes = digest.digest(certBytes)
                    return sha256Bytes.joinToString("") { "%02X".format(it) }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting signature SHA-256", e)
        }
        return ""
    }

    fun verifyIntegrityAndWarn(context: Context): Boolean {
        val currentSignature = getAppSignatureSHA256(context)
        Log.d(TAG, "Current app digital signature SHA-256: $currentSignature")

        val resId = context.resources.getIdentifier("app_signature_sha256", "string", context.packageName)
        val expectedSignature = if (resId != 0) {
            context.getString(resId)
        } else {
            ""
        }

        if (expectedSignature.isEmpty() || expectedSignature == "YOUR_EXPECTED_SHA256" || expectedSignature == "GENERIC") {
            Log.w(TAG, "Integrity verification skipped: NO signature found in strings.xml (Development mode). dynamic signatures log: $currentSignature")
            return true
        }

        if (currentSignature.isNotEmpty() && !currentSignature.equals(expectedSignature, ignoreCase = true)) {
            Log.e(TAG, "INTEGRITY CRITICAL CORRUPTION! Expected: $expectedSignature, Identified: $currentSignature")
            if (context is android.app.Activity) {
                context.runOnUiThread {
                    android.app.AlertDialog.Builder(context)
                        .setTitle("⛔ كشف إعادة تعبئة وتلاعب بالملف (Tampered APK)!")
                        .setMessage("تحذير أمني خطير:\n\nتم الكشف عن إعادة توقيع وتغيير شفرة الـ APK الأصلية! التطبيق معدل أو تمت برمجته بأكواد خارجية خبيثة للتنصت.\n\nتطبيق الدرع الصامت سيغلق الآن فوراً لضمان سلامة الـ VPN وقاعدة بيانات الخزنة.")
                        .setCancelable(false)
                        .setNegativeButton("إغلاق التطبيق") { _, _ ->
                            context.finishAffinity()
                            System.exit(0)
                        }
                        .show()
                }
            }
            return false
        }
        Log.i(TAG, "App signature integrity verification passed. Secure vault and tunnel initialized.")
        return true
    }
}
