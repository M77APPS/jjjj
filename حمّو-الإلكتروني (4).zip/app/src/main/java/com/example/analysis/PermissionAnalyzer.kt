package com.example.analysis

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.ui.AppPermissionInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object PermissionAnalyzer {
    suspend fun getAppsWithSensitivePermissions(context: Context): List<AppPermissionInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        val appList = mutableListOf<AppPermissionInfo>()
        
        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystemApp) continue // Skip cluttering OS applications

            val requestedPermissions = pkg.requestedPermissions
            val hasCamera = requestedPermissions?.contains(android.Manifest.permission.CAMERA) == true
            val hasMic = requestedPermissions?.contains(android.Manifest.permission.RECORD_AUDIO) == true
            val hasLocation = requestedPermissions?.contains(android.Manifest.permission.ACCESS_FINE_LOCATION) == true ||
                    requestedPermissions?.contains(android.Manifest.permission.ACCESS_COARSE_LOCATION) == true
            val hasContacts = requestedPermissions?.contains(android.Manifest.permission.READ_CONTACTS) == true ||
                    requestedPermissions?.contains(android.Manifest.permission.WRITE_CONTACTS) == true
            val hasSms = requestedPermissions?.contains(android.Manifest.permission.READ_SMS) == true ||
                    requestedPermissions?.contains(android.Manifest.permission.RECEIVE_SMS) == true ||
                    requestedPermissions?.contains(android.Manifest.permission.SEND_SMS) == true

            if (hasCamera || hasMic || hasLocation || hasContacts || hasSms) {
                val label = appInfo.loadLabel(pm).toString()
                appList.add(
                    AppPermissionInfo(
                        packageName = pkg.packageName,
                        appName = label,
                        hasCamera = hasCamera,
                        hasMic = hasMic,
                        hasLocation = hasLocation,
                        hasContacts = hasContacts,
                        hasSms = hasSms
                    )
                )
            }
        }
        appList
    }
}
