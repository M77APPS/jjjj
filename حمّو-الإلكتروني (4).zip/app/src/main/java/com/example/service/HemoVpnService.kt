package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppDatabase
import com.example.data.ThreatLog
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress

class HemoVpnService : VpnService() {

    companion object {
        private const val TAG = "HemoVpnService"
        private const val CHANNEL_ID = "hemo_vpn_channel"
        private const val NOTIFICATION_ID = 912

        private val _isVpnRunning = MutableStateFlow(false)
        val isVpnRunning: StateFlow<Boolean> = _isVpnRunning.asStateFlow()

        private val _blockedUrlsCount = MutableStateFlow(0)
        val blockedUrlsCount: StateFlow<Int> = _blockedUrlsCount.asStateFlow()

        // Helper to increment blocked count from outside
        fun incrementBlockedCount() {
            _blockedUrlsCount.value += 1
        }
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand triggered")
        
        // Setup foreground notification
        val notification = createNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Stop any existing thread/job
        stopVpnThread()

        // Establish VPN Interface and start simulated packet loop
        startVpnThread()

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVpnThread()
        serviceScope.cancel()
        Log.d(TAG, "VPN Service Destroyed")
    }

    private fun startVpnThread() {
        _isVpnRunning.value = true
        vpnJob = serviceScope.launch {
            try {
                establishVpn()
                // Simulated sinkhole scanning loop
                while (isActive) {
                    delay(4000)
                    // Check for simulated background URL scan activity
                    // Log.d(TAG, "🛡️ VPN DNS Loopback routing active...")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in VPN service loop", e)
            } finally {
                withContext(Dispatchers.Main) {
                    _isVpnRunning.value = false
                }
            }
        }
    }

    private fun establishVpn() {
        try {
            val builder = Builder()
                .setSession("Hemo Cyber Defender Vpn Tunnel")
                .addAddress("10.8.0.2", 32)
                .addRoute("10.8.0.0", 24)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            vpnInterface = builder.establish()
            Log.d(TAG, "VPN Interface established successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to establish VPN Interface. High probability of emulator/container limits.", e)
        }
    }

    private fun stopVpnThread() {
        vpnJob?.cancel()
        vpnJob = null
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN Interface", e)
        }
        vpnInterface = null
        _isVpnRunning.value = false
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🛡️ حمّو الإلكتروني")
            .setContentText("الدرع الصامت نشط - حمّو الإلكتروني يحميك")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "🛡️ حمّو الإلكتروني للدرع الصامت",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة إشعارات حماية حمّو الإلكتروني وتصفية وحجب الروابط الضارة."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
