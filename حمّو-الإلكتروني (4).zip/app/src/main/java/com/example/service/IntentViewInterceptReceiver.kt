package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.MainActivity

class IntentViewInterceptReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_VIEW) {
            val urlString = intent.dataString
            if (urlString != null) {
                // Abort broadcast so browser doesn't open
                abortBroadcast()

                // Redirect to our MainActivity for inspection
                val interceptIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("INTERCEPTED_URL_KEY", urlString)
                }
                context.startActivity(interceptIntent)
            }
        }
    }
}
