package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.MainActivity
import java.util.concurrent.TimeUnit

class HemoForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private val TAG = "HemoForegroundService"
    private val CHANNEL_ID = "hemo_silent_shield_channel"
    private val NOTIFICATION_ID = 2026

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "HemoForegroundService created")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "HemoForegroundService started")

        // 0. Perform background environment and analysis audit scanner
        val isEmulator = com.example.utils.EnvironmentChecker.isEmulator()
        val isRooted = com.example.utils.EnvironmentChecker.isRooted()
        val isFrida = com.example.utils.EnvironmentChecker.isFridaDetected()
        val isXposed = com.example.utils.EnvironmentChecker.isXposedDetected()
        if (isEmulator || isRooted || isFrida || isXposed) {
            Log.e(TAG, "🔒 [Hemo Silent Shield Service Alert] Insecure environment detected! Emulator: $isEmulator, Rooted: $isRooted, Frida: $isFrida, Xposed: $isXposed")
        }

        // 1. Start foreground service immediately with notification
        val notification = createPersistentNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // 2. Safely acquire CPU WakeLock to keep protection active
        acquireCpuWakeLock()

        // 3. Setup self-repair with WorkManager every 15 minutes to guarantee uptime
        scheduleUptimeSelfRepair()

        return START_STICKY
    }

    override fun onDestroy() {
        releaseCpuWakeLock()
        super.onDestroy()
        Log.d(TAG, "HemoForegroundService destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun acquireCpuWakeLock() {
        try {
            if (wakeLock == null) {
                val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = powerManager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "HemoSilentShield::BackgroundLock"
                ).apply {
                    acquire(10 * 60 * 1000L /* 10 minutes fallback */)
                }
                Log.d(TAG, "WakeLock CPU acquired successfully")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error acquiring WakeLock", e)
        }
    }

    private fun releaseCpuWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                }
            }
            wakeLock = null
            Log.d(TAG, "WakeLock CPU released safely")
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing WakeLock", e)
        }
    }

    private fun scheduleUptimeSelfRepair() {
        try {
            val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
                "HEMO_SELF_REPAIR_JOB",
                ExistingPeriodicWorkPolicy.KEEP,
                syncRequest
            )
            Log.d(TAG, "Periodic WorkManager self-repair scheduled")
        } catch (e: Exception) {
            Log.e(TAG, "Failed scheduling self repair", e)
        }
    }

    private fun createPersistentNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🛡️ الدرع الصامت نشط")
            .setContentText("حمّو الإلكتروني يقوم بفحص الخلفية والشبكات باستمرار.")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "🛡️ قناة الدرع الصامت الدائم لحمّو الإلكتروني",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة مخصصة للدرع الصامت الدائم لمعالجة وتأمين وفحص الاتصالات في الخلفية."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
