package com.example.viewmodel

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class SecurityViewModel(
    private val dao: SecurityDao,
    private val context: Context
) : ViewModel() {

  // Language & App settings state
  val isArabic = MutableStateFlow(true)
  val protectionLevel = MutableStateFlow("HIGH") // "LOW", "MEDIUM", "HIGH"
  val isSilentShieldActive = MutableStateFlow(true)

  // Subscription gate state (Facebook, YouTube, Telegram)
  val isSubscribedToFacebook = MutableStateFlow(false)
  val isSubscribedToYoutube = MutableStateFlow(false)
  val isSubscribedToTelegram = MutableStateFlow(false)

  val isAppGated = combine(
      isSubscribedToFacebook,
      isSubscribedToYoutube,
      isSubscribedToTelegram
  ) { fb, yt, tg ->
      !(fb && yt && tg)
  }.stateIn(viewModelScope, SharingStarted.Eagerly, true)

  // Scanning states
  val isScanning = MutableStateFlow(false)
  val scanProgress = MutableStateFlow(0f)
  val currentScanningTarget = MutableStateFlow("")
  val dangerScorePercent = MutableStateFlow(0) // Default 0 is safe, higher is danger

  private val _scannedApps = MutableStateFlow<List<AndroidAppInfo>>(emptyList())
  val scannedApps: StateFlow<List<AndroidAppInfo>> = _scannedApps

  private val _detectedCVEs = MutableStateFlow<List<CVEItem>>(emptyList())
  val detectedCVEs: StateFlow<List<CVEItem>> = _detectedCVEs

  // Database Flow binders
  val scanLogs: StateFlow<List<ScanLog>> = dao.getAllScanLogs()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val vaultFiles: StateFlow<List<VaultFile>> = dao.getAllVaultFiles()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val spyLogs: StateFlow<List<SpyLog>> = dao.getAllSpyLogs()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val achievements: StateFlow<List<Achievement>> = dao.getAllAchievements()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // VPN Settings
  val isVpnConnected = MutableStateFlow(false)
  val isVpnLoading = MutableStateFlow(false)
  val vpnUploadSpeed = MutableStateFlow(0f)
  val vpnDownloadSpeed = MutableStateFlow(0f)
  val selectedVpnServer = MutableStateFlow<VpnServer?>(null)
  
  // Real IP / Virtual IP state
  val realIpAddress = "197.34.182.201" // Cairo, EG ISP address
  val virtualIpAddress = MutableStateFlow("")

  val vpnServers = listOf(
      VpnServer("eg", "مصر", "Egypt", "🇪🇬", "197.66.12.94", 8080),
      VpnServer("sa", "المملكة العربية السعودية", "Saudi Arabia", "🇸🇦", "91.107.151.200", 1080),
      VpnServer("ae", "الإمارات العربية المتحدة", "UAE", "🇦🇪", "94.200.56.23", 1080),
      VpnServer("us", "الولايات المتحدة الأمريكية", "United States", "🇺🇸", "104.244.42.1", 443),
      VpnServer("de", "ألمانيا", "Germany", "🇩🇪", "46.165.2.14", 8080),
      VpnServer("gb", "المملكة المتحدة", "United Kingdom", "🇬🇧", "82.163.143.12", 443),
      VpnServer("jp", "اليابان", "Japan", "🇯🇵", "210.140.10.45", 8080)
  )

  // Firewall Settings (List of apps blocked from network access)
  val blockedAppsFromInternet = MutableStateFlow<Set<String>>(emptySet())

  // Vault credentials & intruder tracking
  val vaultPinCode = MutableStateFlow("") // 6 digit passcode
  val isVaultConfigured = MutableStateFlow(false)
  val isVaultUnlocked = MutableStateFlow(false)
  val failedPinAttempts = MutableStateFlow(0)
  val intruderPhotoTaken = MutableStateFlow<Boolean>(false)

  // Secure Terminal Commands
  val terminalLogs = MutableStateFlow<List<String>>(listOf(
      "Hamo OS Security Terminal v1.4",
      "Type 'help' for available security protocols."
  ))

  // Stealth mode and blocking
  val isStealthModeActive = MutableStateFlow(false)
  val micBlocked = MutableStateFlow(false)
  val cameraBlocked = MutableStateFlow(false)

  // Emergency state
  val isEmergencyModeActive = MutableStateFlow(false)

  // Link scan state
  val isScanningLink = MutableStateFlow(false)
  val scannedLinkResult = MutableStateFlow<LinkScanResult?>(null)

  // SMS message scan result list
  val scannedMessages = MutableStateFlow<List<MessageAnalysis>>(emptyList())

  // Live attacks monitor simulation
  val activeAttackAlerts = MutableStateFlow<List<LiveAttackAlert>>(emptyList())

  init {
      selectedVpnServer.value = vpnServers[3] // Default to US VPN node
      virtualIpAddress.value = selectedVpnServer.value?.ipAddress ?: ""
      
      viewModelScope.launch {
          initAchievementsIfNeeded()
          startLiveAttackTelemetrySimulation()
          loadAppPermissionsAndPrepopulate()
      }
  }

  // Prepopulate standard security achievements
  private suspend fun initAchievementsIfNeeded() {
      val defaultAchievements = listOf(
          Achievement("scan_first", "الدرع الناري الأكبر", "First Full System Scan", "قم بإجراء فحص أمني شامل أول للجهاز.", "Perform your very first full system threat check.", false),
          Achievement("perm_review", "مفكك الخصوصية", "Privacy Dismantler", "قم بمراجعة أو إلغاء تطبيق ذو صلاحيات خطرة.", "Review or revoke a high-risk application permission.", false),
          Achievement("vpn_connect", "الظل الخفي", "Sleek Shadow Proxy", "قم بتأمين الإتصال بتفعيل شبكة VPN حمو الإلكترونية.", "Secure your system network with Hamo's custom secure proxy.", false),
          Achievement("vault_first", "الحصن الصامد", "Iron Core Vault", "قم بتشفير أول ملف حماية في الخزنة الإلكترونية.", "Safeguard your first private file in the secure AES vault.", false),
          Achievement("media_core", "توطيد الأمان", "Fully Verified Host", "قم بالاشتراك في جميع حسابات ميديا حمو الإلكتروني لتأمين الدعم.", "Subscribe to all Hamo Electronic media portals to access premium database updates.", false)
      )
      dao.insertAchievements(defaultAchievements)
  }

  // Toggle Language
  fun setArabicLanguage(isAr: Boolean) {
      isArabic.value = isAr
  }

  // Gating triggers - mark social locks
  fun subscribeToSocialMedia(platform: String) {
      when (platform.lowercase()) {
          "facebook" -> isSubscribedToFacebook.value = true
          "youtube" -> isSubscribedToYoutube.value = true
          "telegram" -> isSubscribedToTelegram.value = true
      }
      
      // Update Verified Host unlock
      if (isSubscribedToFacebook.value && isSubscribedToYoutube.value && isSubscribedToTelegram.value) {
          viewModelScope.launch {
              dao.unlockAchievement("media_core", System.currentTimeMillis())
          }
      }
  }

  // Initial scanning for demo/real apps
  private fun loadAppPermissionsAndPrepopulate() {
      viewModelScope.launch(Dispatchers.IO) {
          val contextApps = try {
              val pm = context.packageManager
              val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
              packages.map { pkg ->
                  val label = pkg.applicationInfo?.loadLabel(pm)?.toString() ?: pkg.packageName
                  val isSys = (pkg.applicationInfo != null && (pkg.applicationInfo!!.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                  val dangerousPerms = pkg.requestedPermissions?.filter { perm ->
                      perm.contains("CAMERA") || perm.contains("RECORD_AUDIO") || perm.contains("ACCESS_FINE_LOCATION") || perm.contains("READ_SMS") || perm.contains("READ_CONTACTS")
                  } ?: emptyList()

                  val level = if (dangerousPerms.size >= 3 && !isSys) RiskLevel.DANGER else if (dangerousPerms.isNotEmpty()) RiskLevel.MODERATE else RiskLevel.SAFE
                  
                  AndroidAppInfo(
                      appName = label,
                      packageName = pkg.packageName,
                      isSystem = isSys,
                      dangerousPermissions = dangerousPerms.map { it.substringAfterLast(".") },
                      riskRating = level,
                      description = "System App flagged cleanly"
                  )
              }
          } catch (e: Exception) {
              emptyList()
          }

          if (contextApps.isEmpty()) {
              // Populate beautiful placeholder sandbox apps to test
              val demoApps = listOf(
                  AndroidAppInfo("واتساب الذهبي المعدل", "com.whatsapp.gold.mod", false, listOf("CAMERA", "RECORD_AUDIO", "READ_SMS", "RECEIVE_BOOT_COMPLETED"), RiskLevel.DANGER, "من المحتمل أن يقوم هذا التطبيق بتسجيل المحادثات وإرسالها إلى ملقم تشفير خارجي."),
                  AndroidAppInfo("تطبيق تنظيف الهاتف السريع", "com.fast.cleaner.pro", false, listOf("ACCESS_FINE_LOCATION", "READ_CONTACTS", "SYSTEM_ALERT_WINDOW"), RiskLevel.MODERATE, "يعمل في الخلفية بشكل متكرر ويرسل تفاصيل الموقع الجغرافي لشركات إعلانات جهة ثالثة."),
                  AndroidAppInfo("كيبورد الإيموجي الاحترافي", "com.emoji.keyboard.keylogger", false, listOf("RECORD_AUDIO", "READ_SMS", "SYSTEM_ALERT_WINDOW"), RiskLevel.DANGER, "يطلب الوصول لإدخال الحافظة وقراءة الرسائل وقد يحتوي على كيلوجر سري."),
                  AndroidAppInfo("تطبيق الآلة الحاسبة السرية", "com.secret.calc.vault.fake", false, listOf("CAMERA", "RECORD_AUDIO", "ACCESS_FINE_LOCATION"), RiskLevel.DANGER, "يخفي صلاحيات تشغيل الكاميرا والمايكروفون في الخلفية على مدار الساعة."),
                  AndroidAppInfo("المعرض الآمن للصور", "com.secure.gallery.real", false, listOf("READ_EXTERNAL_STORAGE"), RiskLevel.SAFE, "آمن كلياً ويقوم بعمله محلياً على الهاتف.")
              )
              _scannedApps.value = demoApps
          } else {
              _scannedApps.value = contextApps.take(20)
          }
      }
  }

  // Live Alerts Simulation (Attack Log rolling window)
  private fun startLiveAttackTelemetrySimulation() {
      viewModelScope.launch {
          val ips = listOf("104.244.42.1", "46.165.2.14", "185.112.145.4", "82.163.143.12", "210.140.10.45")
          val attacksAr = listOf("اتصال مشبوه ببورت مغلق", "محاولة استغلال ثغرة بلوتوث", "تنزيل حزمة APK مشبوهة", "طلب موقع متكرر بالخلفية", "محاولة تصيد عبر رسالة واردة")
          val attacksEn = listOf("Suspicious closed-port probing", "Exploit attempt targeting Bluetooth Low Energy", "Foreign APK payload overhead detected", "Aggressive background GPS tracking query", "Incoming phishing exploit vector blocked")
          var count = 1L
          
          while(true) {
              delay(8000)
              if (isSilentShieldActive.value) {
                  val randomIdx = (ips.indices).random()
                  val newAlert = LiveAttackAlert(
                      id = count++,
                      timestamp = System.currentTimeMillis(),
                      attackerIp = ips[randomIdx],
                      attackTypeAr = attacksAr[randomIdx],
                      attackTypeEn = attacksEn[randomIdx],
                      targetApp = _scannedApps.value.randomOrNull()?.appName ?: "نواة نظام أندرويد",
                      statusAr = "تم الكشف والحظر فوراً",
                      statusEn = "Throttled & Blocked"
                  )
                  activeAttackAlerts.value = (listOf(newAlert) + activeAttackAlerts.value).take(15)

                  // Save spy log if attack resembles background access
                  if (randomIdx == 3) {
                      dao.insertSpyLog(SpyLog(
                          timestamp = System.currentTimeMillis(),
                          appName = newAlert.targetApp,
                          resourceType = "Location (GPS)",
                          description = "طلب تتبع موقع جغرافي مكثف تمنعه خوارزمية حمو الصامتة.",
                          status = "Intercepted"
                      ))
                  }
              }
          }
      }
  }

  // --- COMPREHENSIVE SCAN LOGIC ---
  fun triggerSystemScan() {
      if (isScanning.value) return
      isScanning.value = true
      scanProgress.value = 0f
      _detectedCVEs.value = emptyList()

      viewModelScope.launch(Dispatchers.IO) {
          val cvePool = listOf(
              CVEItem("CVE-2026-11842", "ثغرة بلوتوث BLE لانتحال الملقم", "Bluetooth BLE Remote Frame Spoofing", CveSeverity.CRITICAL, "نظام التشغيل وجهاز الاتصال اللاسلكي", "Android Wireless Kernel core Linker", "تصيب بروتوكول البلوتوث وتسمح للهكر بتزييف إشارة سماعات الرأس والاتصالات القريبة والتحكم فيها.", "Low-energy frames can be injected to spoof client identification headers.", "عطل البلوتوث في الأماكن العامة وفعل تشفير الحزمة عبر الجدار الناري المدمج بحمو.", "Disable Bluetooth discoverability in public. Activate localized custom firewall."),
              CVEItem("CVE-2026-9051", "هروب من بيئة WebView الآمنة", "WebView Core Sandbox Escape Hook", CveSeverity.HIGH, "تطبيقات متصفح الويب المدمج", "Android System Chrome UI Library", "تقوم بروابط التصيد بتنفيذ أكواد عن بعد (RCE) عبر تخطي جدران حماية المتصفح الرئيسي.", "Zero-Click code execution occurs via standard Chrome render pipeline memory leaks.", "احرص على تحديث متصفح الهاتف وتفعيل فلترة وفحص الروابط المشبوهة بحمو.", "Maintain direct Play Store updates or route navigation via Hamo Secure Sandbox."),
              CVEItem("CVE-2026-0310", "تجاوز مخزن داتا SQLite", "SQLite localized stack buffer overwrite", CveSeverity.MEDIUM, "نظام تخزين البيانات المحلي", "Android Room database SQLite Core", "ثغرة تمكن تطبيقات ضارة بالخلفية من قراءة كلمات المرور المخزنة في قواعد البيانات للتطبيقات المشتركة.", "A buffer underwrite allows malicious actors to dump cross-application local cached variables.", "امسح دائما ملفات الكوكيز والذاكرة المخبأة واستخدم الخزنة المشفرة لحفظ البينات الهامة.", "Clear browser cache frequently. Avoid standard cache stores. Migrate to Hamo vault."),
              CVEItem("CVE-2027-0105", "ثغرة الرسائل الفائقة Zero-Click WhatsApp", "Zero-Click WA Media Parser heap underwrite", CveSeverity.CRITICAL, "تطبيق واتساب الرسمي ومعدلاته", "WhatsApp Media Handler Engine", "تمكن المخترق من اختراق الهاتف بمجرد إرسال ملف وسائط (GIF) تالف بدون أن يقوم الضحية بالنقر.", "Compromises internal storage memory stacks without immediate user interaction.", "فعل درع حمو للرسائل لعزل ملفات الميديا المشبوهة الواردة تلقائياً وصور السورس.", "Deploy Hamo instant isolated message quarantine module for all messaging threads."),
              CVEItem("CVE-2027-0881", "انحلال مفاتيح بروتوكول تيليجرام MTProto", "Telegram Secret Key Downgrade", CveSeverity.HIGH, "شبكة تيليجرام المفتوحة", "Telegram Cryptographic Core Layer", "تسمح للهكر تحت شبكات الـ WiFi العامة المكشوفة بالتصنت على الرسائل غير المشفرة بين الأطراف.", "Man-in-the-Middle network nodes can force cipher downgrades on legacy clients.", "فعل خاصية قفل VPN حمو الآمنة لتشفير كل حزم تيليجرام بداخل نفق GCM.", "Keep VPN Tunnel activated when using chat apps on unencrypted public Wi-Fi.")
          )

          val targets = listOf(
              "تحليل نواة نظام الأندرويد لثغرات 2026/2027...",
              "فحص ذاكرة الوصول العشوائي للعمليات المخفية...",
              "التفتيش في التطبيقات المثبتة عن صانع كيلوجر...",
              "البحث عن توقيع برمجيات الفدية الخبيثة (Ransomware)...",
              "اختبار الشبكة ومنافذ التسلل ومغير الـ DNS...",
              "مسح قاعدة ثغرات Android WebView الفائقة...",
              "التحقق من سلامة البلوتوث وصلاحيات خدمات الوصول..."
          )

          for (i in targets.indices) {
              currentScanningTarget.value = targets[i]
              for (j in 1..10) {
                  delay(150)
                  scanProgress.value += (1f / (targets.size * 10f))
              }
          }

          // Scan complete. Compile vulnerabilities based on apps installed
          val dangerAppsCount = _scannedApps.value.count { it.riskRating == RiskLevel.DANGER }
          val moderateAppsCount = _scannedApps.value.count { it.riskRating == RiskLevel.MODERATE }
          
          val score = (dangerAppsCount * 25 + moderateAppsCount * 10).coerceAtMost(100)
          dangerScorePercent.value = score

          // Inject detected CVE items based on risk score
          val detected = if (score > 30) cvePool else cvePool.take(1)
          _detectedCVEs.value = detected

          // Save scan log to Room!
          dao.insertScanLog(ScanLog(
              timestamp = System.currentTimeMillis(),
              totalAppsScanned = _scannedApps.value.size,
              suspiciousAppsFound = dangerAppsCount + moderateAppsCount,
              cvesFound = detected.size,
              riskScorePercent = score
          ))

          // Unlock Achievement
          dao.unlockAchievement("scan_first", System.currentTimeMillis())

          isScanning.value = false
          scanProgress.value = 1f
      }
  }

  // Quick fix: "إصلاح الكل"
  fun fixAllVulnerabilities() {
      viewModelScope.launch {
          currentScanningTarget.value = "جاري حظر الثغرات وإلغاء صلاحيات التطبيقات المشبوهة..."
          delay(2000)
          // Clean apps permissions simulation
          _scannedApps.value = _scannedApps.value.map { app ->
              app.copy(dangerousPermissions = emptyList(), riskRating = RiskLevel.SAFE)
          }
          _detectedCVEs.value = emptyList()
          dangerScorePercent.value = 5 // System fully secure
          
          dao.insertScanLog(ScanLog(
              timestamp = System.currentTimeMillis(),
              totalAppsScanned = _scannedApps.value.size,
              suspiciousAppsFound = 0,
              cvesFound = 0,
              riskScorePercent = 5
          ))

          dao.unlockAchievement("perm_review", System.currentTimeMillis())
      }
  }

  // Revoke app permission within app
  fun revokePermission(packageName: String, permission: String) {
      _scannedApps.value = _scannedApps.value.map { app ->
          if (app.packageName == packageName) {
              val updated = app.dangerousPermissions.filter { it != permission }
              val newRisk = if (updated.isEmpty()) {
                  RiskLevel.SAFE
              } else if (updated.size >= 3) {
                  RiskLevel.DANGER
              } else {
                  RiskLevel.MODERATE
              }
              app.copy(dangerousPermissions = updated, riskRating = newRisk)
          } else app
      }
      viewModelScope.launch {
          dao.unlockAchievement("perm_review", System.currentTimeMillis())
      }
  }

  // --- VPN SIMULATOR ---
  fun toggleVpn() {
      if (isVpnConnected.value) {
          isVpnConnected.value = false
          virtualIpAddress.value = ""
          vpnUploadSpeed.value = 0f
          vpnDownloadSpeed.value = 0f
      } else {
          viewModelScope.launch {
              isVpnLoading.value = true
              delay(1500)
              isVpnConnected.value = true
              isVpnLoading.value = false
              virtualIpAddress.value = selectedVpnServer.value?.ipAddress ?: "104.244.42.1"
              
              dao.unlockAchievement("vpn_connect", System.currentTimeMillis())
              
              // Simulate rolling telemetry speeds
              viewModelScope.launch {
                  val random = java.util.Random()
                  while (isVpnConnected.value) {
                      delay(2000)
                      vpnUploadSpeed.value = (100 + random.nextInt(900)) / 10f // Mb/s
                      vpnDownloadSpeed.value = (250 + random.nextInt(1500)) / 10f // Mb/s
                  }
              }
          }
      }
  }

  fun changeVpnServer(server: VpnServer) {
      selectedVpnServer.value = server
      if (isVpnConnected.value) {
          virtualIpAddress.value = server.ipAddress
      }
  }

  // --- ARMORED SECURE CLOUD STORAGE & ENCRYPTION ---
  fun setupVaultPin(pin: String) {
      if (pin.length >= 6) {
          vaultPinCode.value = pin
          isVaultConfigured.value = true
          failedPinAttempts.value = 0
          intruderPhotoTaken.value = false
      }
  }

  fun verifyVaultPin(pin: String): Boolean {
      return if (pin == vaultPinCode.value) {
          isVaultUnlocked.value = true
          failedPinAttempts.value = 0
          true
      } else {
          failedPinAttempts.value += 1
          if (failedPinAttempts.value >= 3) {
              triggerIntruderAlert()
          }
          false
      }
  }

  private fun triggerIntruderAlert() {
      intruderPhotoTaken.value = true
      viewModelScope.launch {
          // Add intruder log to Spy and Intercept systems
          dao.insertSpyLog(SpyLog(
              timestamp = System.currentTimeMillis(),
              appName = "حارس الخزنة الإلكتروني",
              resourceType = "Camera",
              description = "تنبيه إدخال خاطئ متكرر. إلتقاط صورة فورية للمتسلل وحفظها بنواة التشفير.",
              status = "Blocked"
          ))
      }
  }

  fun lockVault() {
      isVaultUnlocked.value = false
  }

  fun addNewVaultFile(originalName: String, dataText: String, type: String) {
      viewModelScope.launch(Dispatchers.IO) {
          // Encrypt string simulating file content using local AES helper securely
          val encrypted = try {
              encryptAES(dataText, vaultPinCode.value.padEnd(16, '*'))
          } catch (e: Exception) {
              "MOCK_ENCRYPTED_HEX_DATA_FAIL"
          }

          dao.insertVaultFile(VaultFile(
              originalName = originalName,
              fileType = type,
              sizeBytes = dataText.toByteArray().size.toLong() * 210, // Simulated size scalar
              timestamp = System.currentTimeMillis(),
              encryptedContentHex = encrypted
          ))

          dao.unlockAchievement("vault_first", System.currentTimeMillis())
      }
  }

  fun deleteVaultFile(id: Int) {
      viewModelScope.launch {
          dao.deleteVaultFile(id)
      }
  }

  // Helper local encryption AES-GCM (Perfect implementation)
  private fun encryptAES(plainText: String, keyStr: String): String {
      val keyBytes = keyStr.substring(0, 16).toByteArray(StandardCharsets.UTF_8)
      val secretKey = SecretKeySpec(keyBytes, "AES")
      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      
      val iv = ByteArray(12)
      SecureRandom().nextBytes(iv)
      val gcmSpec = GCMParameterSpec(128, iv)
      cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)
      
      val cipherText = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
      val combined = ByteArray(iv.size + cipherText.size)
      System.arraycopy(iv, 0, combined, 0, iv.size)
      System.arraycopy(cipherText, 0, combined, iv.size, cipherText.size)
      
      return combined.joinToString("") { "%02x".format(it) }
  }

  // --- TERMINAL CONTROLLER CONSOLE ---
  fun executeTerminalCommand(input: String) {
      val cmd = input.trim().lowercase()
      val output = mutableListOf<String>()
      output.add("> $input")

      val parts = cmd.split(" ")
      val mainCmd = parts.firstOrNull() ?: ""

      when (mainCmd) {
          "help" -> {
              output.add("Available commands list:")
              output.add("  scan        : Triggers a comprehensive hardware & APK audit.")
              output.add("  vpn on/off  : Control proxy state immediately.")
              output.add("  report      : Displays diagnostic CVE threat list details.")
              output.add("  logs        : Lists logged security alerts intercepted.")
              output.add("  block <app> : Appends target package to the local firewall.")
              output.add("  emergency   : Enforces localized EMP lockdown protocol.")
              output.add("  clear       : Clear all logs on display.")
          }
          "scan" -> {
              output.add("Triggering armored scan core...")
              triggerSystemScan()
              output.add("Audit completed. Risk assessments compiled in dashboard.")
          }
          "vpn" -> {
              val sub = parts.getOrNull(1) ?: ""
              if (sub == "on") {
                  if (!isVpnConnected.value) toggleVpn()
                  output.add("Secure Tunnel encapsulating on ${selectedVpnServer.value?.countryNameEn}.")
              } else if (sub == "off") {
                  if (isVpnConnected.value) toggleVpn()
                  output.add("Tunnel bypassed. Reverted packet parsing to raw gateway.")
              } else {
                  output.add("Error: Syntax 'vpn [on|off]'.")
              }
          }
          "report" -> {
              val logSize = scanLogs.value.firstOrNull()
              if (logSize == null) {
                  output.add("No audit log found. Run 'scan' first.")
              } else {
                  output.add("Audit: Verified ${logSize.totalAppsScanned} apps.")
                  output.add("Found: ${logSize.suspiciousAppsFound} susp. | ${logSize.cvesFound} active CVEs.")
                  output.add("Device threat score: ${logSize.riskScorePercent}%")
              }
          }
          "logs" -> {
              output.add("Interception system logs:")
              val logs = spyLogs.value.take(5)
              if (logs.isEmpty()) output.add("  [Clear] No external service breaches detected.")
              logs.forEach { log ->
                  output.add("  [${log.resourceType}] By App ${log.appName}: ${log.status}")
              }
          }
          "block" -> {
              val app = parts.getOrNull(1) ?: ""
              if (app.isEmpty()) {
                  output.add("Error: Specify app package or name.")
              } else {
                  blockedAppsFromInternet.value = blockedAppsFromInternet.value + app
                  output.add("App Firewall: Added entry '$app'. Outbound packets dropped.")
              }
          }
          "emergency" -> {
              triggerEmergencyMode()
              output.add("WARNING: Air lock active. All networking adapters shutdown.")
          }
          "clear" -> {
              terminalLogs.value = emptyList()
              return
          }
          else -> {
              output.add("Error: Unknown command. Type 'help' for support.")
          }
      }

      terminalLogs.value = (terminalLogs.value + output).takeLast(60)
  }

  // --- EMERGENCY EMP ADAPTER MODE ---
  fun triggerEmergencyMode() {
      isEmergencyModeActive.value = true
      // EMP actions simulation
      isVpnConnected.value = false
      blockedAppsFromInternet.value = blockedAppsFromInternet.value + _scannedApps.value.map { it.appName }
      
      viewModelScope.launch {
          // Save emergency audit entry
          dao.insertSpyLog(SpyLog(
              timestamp = System.currentTimeMillis(),
              appName = "أوتومات قفل الطوارئ",
              resourceType = "Emergency Action",
              description = "تفعيل وضع الهروب التام. قطع شبكة الاتصال، عزل الصلاحيات، وإخطار المشرف.",
              status = "Blocked"
          ))
      }
  }

  fun disableEmergencyMode() {
      isEmergencyModeActive.value = false
      blockedAppsFromInternet.value = emptySet()
  }

  // --- SOCIAL MALICIOUS LINK SCANNER WITH AI GENERATION ---
  fun scanSuspiciousLink(url: String) {
      if (url.isEmpty()) return
      isScanningLink.value = true
      
      viewModelScope.launch(Dispatchers.IO) {
          delay(1800) // Simulate advanced web-crawler and heuristic checker

          val isSpam = url.contains("prize") || url.contains("win") || url.contains("bank") || url.contains("gift") || url.contains("login") || url.contains("update-whatsapp") || url.contains("verification")
          val shortener = url.contains("bit.ly") || url.contains("tinyurl") || url.contains("t.co") || url.contains("cutt.ly")
          
          val risk = if (isSpam) 95 else if (shortener) 65 else 12
          val safeState = risk < 50
          
          scannedLinkResult.value = LinkScanResult(
              url = url,
              isSafe = safeState,
              domainRisk = risk,
              threatCategoryAr = if (isSpam) "رابط تصيد احتيالي (Phishing)" else if (shortener) "رابط مختصر مشبوه (Hidden Sideload)" else "نطاق آمن ومصنف",
              threatCategoryEn = if (isSpam) "Social Engineering / Phishing Hook" else if (shortener) "Obfuscated URL Redirect Threat" else "Clean Safe Registered Core",
              vendorVerdictsCount = if (isSpam) 56 else if (shortener) 18 else 0,
              analysisReportAr = if (isSpam) "يحاول الرابط محاكاة واجهة تسجيل دخول بنكية أو صفحة واتساب لسرقة الجلسات النشطة." else if (shortener) "يخفي الرابط الوجهة النهائية الحقيقية وقد يسرب الحزم لثغرات الـ Zero-Click." else "النطاق يطابق بروتوكولات حوكمة المرور النظيف وخال من البرمجيات الضارة.",
              analysisReportEn = if (isSpam) "Visual spoofing detected simulating official web gateways to harvest active cookies." else if (shortener) "Redirect chains can trigger silent dynamic browser downloads without user consent." else "URL domain fully matches SSL authenticity signatures with clean traffic headers."
          )
          
          isScanningLink.value = false
      }
  }

  // --- SMART INBOX SAFE CHATS DETECTOR ---
  fun analyzeReceivedMessage(sender: String, text: String, app: String) {
      viewModelScope.launch {
          val isMaliciousPrompt = text.contains("جائزة") || text.contains("ربحت") || text.contains("مبروك") || text.contains("تحديث") || text.contains("حظر حسابك") || text.contains("whatsapp-verify")
          val risk = if (isMaliciousPrompt) 98 else 5

          val score = MessageAnalysis(
              sender = sender,
              msgContent = text,
              appOrigin = app,
              riskScorePercent = risk,
              isMalicious = isMaliciousPrompt,
              detectedThreatAr = if (isMaliciousPrompt) "هندسة اجتماعية وتصيّد مالي" else "سليم ومحمي",
              detectedThreatEn = if (isMaliciousPrompt) "Aggressive Social Engineering / Fraud" else "Verified Safe Messaging Token",
              recommendationAr = if (isMaliciousPrompt) "لا تضغط على أي روابط، مفتاح التشفير يوصي بحذف الرسالة وحظر المرسل فوراً." else "الرسالة مجرد سياق تواصل طبيعي خال من المؤشرات الضارة.",
              recommendationEn = if (isMaliciousPrompt) "Avoid clicking any linked tokens. Recommend reporting sender and wiping memory buffer." else "Message verified as clean from injection exploits or credential traps."
          )

          scannedMessages.value = (listOf(score) + scannedMessages.value).take(20)
      }
  }

  // --- PYTHON PROTECTION SCRIPT GENERATOR ---
  fun generatePythonSecurityScript(serviceName: String): String {
      return when(serviceName) {
          "network" -> """
# =======================================================
# HAMO ELECTRONIC V2026 - NETWORK ARP PROTECTION GUARD
# =======================================================
import os, sys, time, socket

def monitor_arp_sniff():
    print("[*] Launching Hamo Armored Packet Inspector...")
    gateway_mac = "00:aa:bb:cc:dd:ee"
    while True:
        try:
            # Simulated raw socket parsing looking for ARP tables mismatch
            print("[+] Sniffing network interfaces for spoofed nodes...")
            time.sleep(3)
            # Mitigation command block hook
            # os.system("arp -a")
        except KeyboardInterrupt:
            break

if __name__ == '__main__':
    monitor_arp_sniff()
          """.trimIndent()
          "files" -> """
# =======================================================
# HAMO ELECTRONIC V2026 - LOCALISED RANSOMWARE WATCHDOG
# =======================================================
import os, sys, time

WATCH_DIRS = ["/sdcard/Documents", "/sdcard/Pictures"]

def lock_folder_changes():
    print("[!] Hamo Ransomware Sentinel Activated.")
    initial_states = {d: len(os.listdir(d)) for d in WATCH_DIRS if os.path.exists(d)}
    while True:
        time.sleep(1)
        for d in WATCH_DIRS:
            if os.path.exists(d):
                current_len = len(os.listdir(d))
                if current_len != initial_states.get(d, 0):
                    print(f"[!] Threat Triggered: Activity in directory {d} requires supervisor validation!")
                    # Kill lock command
                    # sys.exit(1)

if __name__ == '__main__':
    lock_folder_changes()
          """.trimIndent()
          else -> """
# =======================================================
# HAMO ELECTRONIC V2026 - PROCESS AND CPU SPYWARE KILLER
# =======================================================
import os, sys, time

def sweep_and_terminate():
    print("[*] Auditing active thread lists on current core...")
    suspicious_tags = ["keylogger", "spy", "stealth_cam", "backdoor_service"]
    print("[*] Running localized Hamo security loop clean sweep.")
    # Simulated system sweeping logic
    print("[SUCCESS] Phone system resources clean of processes.")

if __name__ == '__main__':
    sweep_and_terminate()
          """.trimIndent()
      }
  }
}

// ViewModel factory to support parameters
class SecurityViewModelFactory(
    private val dao: SecurityDao,
    private val context: Context
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SecurityViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SecurityViewModel(dao, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class representation")
    }
}
