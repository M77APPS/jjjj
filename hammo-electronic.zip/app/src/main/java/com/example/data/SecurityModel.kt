package com.example.data

// Scanned application characteristics
data class AndroidAppInfo(
    val appName: String,
    val packageName: String,
    val isSystem: Boolean,
    val dangerousPermissions: List<String>,
    val riskRating: RiskLevel,
    val description: String
)

enum class RiskLevel {
    SAFE, MODERATE, DANGER
}

// Security Vulnerabilities (CVE database)
data class CVEItem(
    val code: String, // e.g. CVE-2026-1182
    val threatNameAr: String,
    val threatNameEn: String,
    val severity: CveSeverity,
    val affectedSystemAr: String,
    val affectedSystemEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val mitigationAr: String,
    val mitigationEn: String
)

enum class CveSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}

// VPN Server node specification
data class VpnServer(
    val id: String,
    val countryNameAr: String,
    val countryNameEn: String,
    val flagEmoji: String,
    val ipAddress: String,
    val socksProxyPort: Int,
    val isPremium: Boolean = false
)

// Malware scanning for URL analysis
data class LinkScanResult(
    val url: String,
    val isSafe: Boolean,
    val domainRisk: Int, // Percentage
    val threatCategoryAr: String,
    val threatCategoryEn: String,
    val vendorVerdictsCount: Int,
    val analysisReportAr: String,
    val analysisReportEn: String
)

// Message safety analysis for SMS / WhatsApp / Telegram
data class MessageAnalysis(
    val sender: String,
    val msgContent: String,
    val appOrigin: String, // "WhatsApp", "Telegram", "SMS"
    val riskScorePercent: Int,
    val isMalicious: Boolean,
    val detectedThreatAr: String,
    val detectedThreatEn: String,
    val recommendationAr: String,
    val recommendationEn: String
)

// Live Security Log events
data class LiveAttackAlert(
    val id: Long,
    val timestamp: Long,
    val attackerIp: String,
    val attackTypeAr: String,
    val attackTypeEn: String,
    val targetApp: String,
    val statusAr: String,
    val statusEn: String
)
