package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// 1. Scan Logs Entity
@Entity(tableName = "scan_logs")
data class ScanLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val totalAppsScanned: Int,
    val suspiciousAppsFound: Int,
    val cvesFound: Int,
    val riskScorePercent: Int
)

// 2. Encrypted Vault Metadata Entity
@Entity(tableName = "vault_files")
data class VaultFile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originalName: String,
    val fileType: String, // "Image", "Video", "Document"
    val sizeBytes: Long,
    val timestamp: Long,
    val encryptedContentHex: String // Simulated secure hexadecimal storage
)

// 3. Spy / Intrusion Logs Entity
@Entity(tableName = "spy_logs")
data class SpyLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val appName: String,
    val resourceType: String, // "Camera", "Microphone", "Location (GPS)"
    val description: String,
    val status: String // "Blocked" or "Intercepted"
)

// 4. Achievement Entity
@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey val id: String,
    val badgeNameAr: String,
    val badgeNameEn: String,
    val descTextAr: String,
    val descTextEn: String,
    val isUnlocked: Boolean,
    val unlockedAt: Long = 0
)

// --- DAOs ---

@Dao
interface SecurityDao {
    // Scan Logs
    @Query("SELECT * FROM scan_logs ORDER BY timestamp DESC")
    fun getAllScanLogs(): Flow<List<ScanLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScanLog(log: ScanLog)

    @Query("DELETE FROM scan_logs")
    suspend fun clearScanLogs()

    // Vault Files
    @Query("SELECT * FROM vault_files ORDER BY timestamp DESC")
    fun getAllVaultFiles(): Flow<List<VaultFile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultFile(file: VaultFile)

    @Query("DELETE FROM vault_files WHERE id = :id")
    suspend fun deleteVaultFile(id: Int)

    // Spy Logs
    @Query("SELECT * FROM spy_logs ORDER BY timestamp DESC")
    fun getAllSpyLogs(): Flow<List<SpyLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpyLog(log: SpyLog)

    @Query("DELETE FROM spy_logs")
    suspend fun clearSpyLogs()

    // Achievements
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<Achievement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievement(achievement: Achievement)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<Achievement>)

    @Query("UPDATE achievements SET isUnlocked = 1, unlockedAt = :timestamp WHERE id = :id")
    suspend fun unlockAchievement(id: String, timestamp: Long)
}

// --- App Room Database ---

@Database(
    entities = [ScanLog::class, VaultFile::class, SpyLog::class, Achievement::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun securityDao(): SecurityDao
}
