package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.VisibleForTesting
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.ui.components.GateScreen
import com.example.ui.components.HamoAppShell
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.SecurityViewModel
import com.example.viewmodel.SecurityViewModelFactory

class MainActivity : ComponentActivity() {

    @VisibleForTesting
    lateinit var db: AppDatabase
    
    @VisibleForTesting
    lateinit var securityViewModel: SecurityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room Database local connection
        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "hamo_security_db"
        )
        .fallbackToDestructiveMigration()
        .build()

        val factory = SecurityViewModelFactory(db.securityDao(), applicationContext)
        securityViewModel = ViewModelProvider(this, factory)[SecurityViewModel::class.java]

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    val isGated by securityViewModel.isAppGated.collectAsState()

                    if (isGated) {
                        GateScreen(viewModel = securityViewModel)
                    } else {
                        HamoAppShell(viewModel = securityViewModel)
                    }
                }
            }
        }
    }
}
