package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SpywareView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val isStealthOn by viewModel.isStealthModeActive.collectAsState()
    val isMicBlocked by viewModel.micBlocked.collectAsState()
    val isCamBlocked by viewModel.cameraBlocked.collectAsState()
    val logs by viewModel.spyLogs.collectAsState()

    var activeTab by remember { mutableStateOf("detector") } // "detector" or "radar"
    
    // Links / Msg simulation state
    var pastedLink by remember { mutableStateOf("") }
    val linkResult by viewModel.scannedLinkResult.collectAsState()
    val isScanningLink by viewModel.isScanningLink.collectAsState()

    var chatSender by remember { mutableStateOf("مخترع الجوائز") }
    var chatMsg by remember { mutableStateOf("مبروك! لقد فزت بـ 100,000 دولار من مسابقة حمو! اضغط هنا لتسجيل بياناتك البنكية: hamo-prizes.com") }
    val chatsExt by viewModel.scannedMessages.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp)
    ) {
        // Upper Tabs Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberBgCard, RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            Button(
                onClick = { activeTab = "detector" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "detector") CyberPrimary else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAr) "رادار وكاشف التجسس" else "Spyware Detector",
                    color = if (activeTab == "detector") CyberBg else CyberTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = { activeTab = "radar" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "radar") CyberPrimary else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAr) "محلل الروابط والشات" else "Link & Message Audit",
                    color = if (activeTab == "radar") CyberBg else CyberTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == "detector") {
            // Spyware hardware & process monitor
            Column(modifier = Modifier.fillMaxSize()) {
                
                // Stealth Mode Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(1.dp, if (isStealthOn) CyberError.copy(0.5f) else CyberPrimary.copy(0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isAr) "🥷 وضع التخفي التام (Stealth)" else "🥷 Stealth Mode Active",
                                color = if (isStealthOn) CyberError else CyberPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAr)
                                    "تعطيل وفصل الكاميرا والمايكروفون تلقائياً وإصدار صفارات إنذار عند كشف محاولة تصنت."
                                    else "Instantly locks down camera frames and activates alarm when unrequested thread triggers.",
                                color = CyberTextSecondary,
                                fontSize = 10.sp,
                                lineHeight = 13.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        
                        Switch(
                            checked = isStealthOn,
                            onCheckedChange = { viewModel.isStealthModeActive.value = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberError,
                                checkedTrackColor = CyberError.copy(0.3f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Camera & Microphone blockers dials
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BlockerCard(
                        title = if (isAr) "حاجب الكاميرا" else "Camera Guard",
                        isBlocked = isCamBlocked,
                        onToggle = { viewModel.cameraBlocked.value = !isCamBlocked },
                        color = CyberPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    BlockerCard(
                        title = if (isAr) "حاجب المايكروفون" else "Audio Guard",
                        isBlocked = isMicBlocked,
                        onToggle = { viewModel.micBlocked.value = !isMicBlocked },
                        color = CyberSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Espionage logs
                Text(
                    text = if (isAr) "📋 سجل محاولات التجسس والاعتراض" else "📋 ESPIONAGE AND INTERCEPT LOGS",
                    color = CyberPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (logs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isAr) "لا توجد محاولات تطفل نشطة. النظام آمن كلياً" else "Clean logs. No hardware intrusion blocks.",
                            color = CyberTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(logs) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = CyberBgCard.copy(0.7f)),
                                border = BorderStroke(0.5.dp, CyberError.copy(0.2f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = when(log.resourceType) {
                                            "Camera" -> Icons.Default.CameraAlt
                                            "Microphone" -> Icons.Default.Mic
                                            else -> Icons.Default.MyLocation
                                        },
                                        contentDescription = log.resourceType,
                                        tint = CyberError,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(text = log.appName, color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "${log.resourceType} - ${log.description}", color = CyberTextSecondary, fontSize = 11.sp)
                                        Text(
                                            text = if (isAr) "الحالة المطبقة: تم العزل" else "Remediation state: BLOCKED",
                                            color = CyberTertiary,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // URL Links & message parsing analyzer
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Link Scanner Box
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                        border = BorderStroke(1.dp, CyberPrimary.copy(0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isAr) "🔗 ماسح وفاحص الروابط المشبوهة" else "🔗 SUSPICIOUS LINK AND ZERO-CLICK SCRUTINY",
                                color = CyberPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            OutlinedTextField(
                                value = pastedLink,
                                onValueChange = { pastedLink = it },
                                placeholder = { Text("https://hamo-unlocked.com", fontSize = 12.sp) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = CyberTextPrimary)
                            )
                            
                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { viewModel.scanSuspiciousLink(pastedLink) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isScanningLink) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBg)
                                } else {
                                    Text(text = if (isAr) "تحليل الرابط رقمياً" else "Analyze URL Authenticity", color = CyberBg, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Output
                            linkResult?.let { res ->
                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = Color.Gray.copy(0.1f))
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(if (res.isSafe) CyberTertiary else CyberError, RoundedCornerShape(4.dp))
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isAr) "درجة الخطورة: ${res.domainRisk}%" else "Risk Coefficient: ${res.domainRisk}%",
                                        color = if (res.isSafe) CyberTertiary else CyberError,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                Text(
                                    text = if (isAr) "التصنيف: ${res.threatCategoryAr}" else "Vector: ${res.threatCategoryEn}",
                                    color = CyberTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )

                                Text(
                                    text = if (isAr) res.analysisReportAr else res.analysisReportEn,
                                    color = CyberTextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }

                // SMS messaging threat simulation box
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                        border = BorderStroke(1.dp, CyberSecondary.copy(0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isAr) "💬 محاكاة فحص رسائل SMS والتطبيقات" else "💬 CHAT INBOX ANTIPHISHING SIMULATION",
                                color = CyberSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            OutlinedTextField(
                                value = chatSender,
                                onValueChange = { chatSender = it },
                                label = { Text("Sender", fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = CyberTextPrimary)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = chatMsg,
                                onValueChange = { chatMsg = it },
                                label = { Text("Message Text", fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = CyberTextPrimary)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = { viewModel.analyzeReceivedMessage(chatSender, chatMsg, "WhatsApp") },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(text = if (isAr) "تغذية ومحاكاة الاستقبال" else "Simulate Live SMS Packet Trigger", color = CyberTextPrimary)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isAr) "⚠️ إخطارات وتنبيه الرسائل المشبوهة" else "⚠️ EXPLOITATIVE SMS CHILL BLOCK HISTORY",
                        color = CyberPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(chatsExt) { msg ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (msg.isMalicious) CyberError.copy(0.08f) else CyberBgCard),
                        border = BorderStroke(1.dp, if (msg.isMalicious) CyberError.copy(0.4f) else Color.Gray.copy(0.1f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "[${msg.appOrigin}] ${msg.sender}", color = CyberTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (msg.isMalicious) "DANGER ${msg.riskScorePercent}%" else "SAFE",
                                    color = if (msg.isMalicious) CyberError else CyberTertiary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(text = msg.msgContent, color = CyberTextSecondary, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
                            
                            if (msg.isMalicious) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(CyberError.copy(0.12f), RoundedCornerShape(4.dp))
                                        .padding(6.dp)
                                ) {
                                    Column {
                                        Text(text = if (isAr) "⚠️ توصية حمو:" else "⚠️ REMEDIATION:", color = CyberError, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(text = if (isAr) msg.recommendationAr else msg.recommendationEn, color = CyberTextPrimary, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BlockerCard(
    title: String,
    isBlocked: Boolean,
    onToggle: () -> Unit,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onToggle,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBgCard),
        border = BorderStroke(1.dp, if (isBlocked) color else Color.Gray.copy(0.1f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (isBlocked) Icons.Default.GppGood else Icons.Default.GppBad,
                contentDescription = "Lock",
                tint = if (isBlocked) CyberTertiary else Color.Gray.copy(0.6f),
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
                text = if (isBlocked) (if (title.contains("كاميرا") || title.contains("Camera")) "الوصول محجوب" else "المايك مغلق")
                       else (if (title.contains("كاميرا") || title.contains("Camera")) "كاميرا مكشوفة" else "مايك متاح للتشغيل"),
                color = if (isBlocked) CyberTertiary else CyberError,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
