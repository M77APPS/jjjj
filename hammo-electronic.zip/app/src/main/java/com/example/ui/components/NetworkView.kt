package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VpnServer
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@Composable
fun NetworkView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val isVpnOn by viewModel.isVpnConnected.collectAsState()
    val isVpnLoading by viewModel.isVpnLoading.collectAsState()
    val uploadSpd by viewModel.vpnUploadSpeed.collectAsState()
    val downloadSpd by viewModel.vpnDownloadSpeed.collectAsState()
    val activeServer by viewModel.selectedVpnServer.collectAsState()
    val appsBlocked by viewModel.blockedAppsFromInternet.collectAsState()
    val apps by viewModel.scannedApps.collectAsState()

    var activeTab by remember { mutableStateOf("vpn") } // "vpn" or "firewall"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp)
    ) {
        // Toggle tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberBgCard, RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                onClick = { activeTab = "vpn" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "vpn") CyberPrimary else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAr) "شبكة VPN المشفرة" else "Secure VPN",
                    color = if (activeTab == "vpn") CyberBg else CyberTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Button(
                onClick = { activeTab = "firewall" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "firewall") CyberPrimary else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAr) "الجدار الناري الذكي" else "Smart Firewall",
                    color = if (activeTab == "firewall") CyberBg else CyberTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == "vpn") {
            // VPN Section
            Column(modifier = Modifier.fillMaxSize()) {
                // VPN central power switch widget
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(1.dp, if (isVpnOn) CyberTertiary.copy(0.4f) else CyberSecondary.copy(0.3f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isVpnOn) {
                                if (isAr) "تأمين معزز ومحكم للشبكة" else "PACKET WRAP ENCAPSULATION ACTIVE"
                            } else {
                                if (isAr) "الشبكة مكشوفة وغير آمنة" else "RAW PACKETS EXPOSED / UNENCRYPTED"
                            },
                            color = if (isVpnOn) CyberTertiary else CyberSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Dynamic glowing Button core
                        Box(contentAlignment = Alignment.Center) {
                            if (isVpnLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(100.dp),
                                    color = CyberPrimary,
                                    strokeWidth = 4.dp
                                )
                            } else {
                                Surface(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clickable { viewModel.toggleVpn() },
                                    shape = RoundedCornerShape(50),
                                    color = if (isVpnOn) CyberTertiary.copy(0.1f) else CyberSecondary.copy(0.1f),
                                    border = BorderStroke(3.dp, if (isVpnOn) CyberTertiary else CyberSecondary)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.PowerSettingsNew,
                                            contentDescription = "Switch",
                                            tint = if (isVpnOn) CyberTertiary else CyberSecondary,
                                            modifier = Modifier.size(48.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isVpnOn) (if (isAr) "متصل بـ ${activeServer?.countryNameAr}" else "Connected to ${activeServer?.countryNameEn}")
                                   else (if (isAr) "انقر للاتصال بالوكيل" else "Tap to secure Wi-Fi gateway"),
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Telemetry speed metrics
                if (isVpnOn) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SpeedGaugeCard(
                            title = if (isAr) "سرعة الإنزال (DL)" else "Download Speed",
                            speed = "${downloadSpd} Mb/s",
                            color = CyberTertiary,
                            icon = Icons.Default.ArrowDownward,
                            modifier = Modifier.weight(1f)
                        )

                        SpeedGaugeCard(
                            title = if (isAr) "سرعة الرفع (UL)" else "Upload Speed",
                            speed = "${uploadSpd} Mb/s",
                            color = CyberPrimary,
                            icon = Icons.Default.ArrowUpward,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Node country selector header
                Text(
                    text = if (isAr) "🌍 اختر خادم الوكيل الآمن لقفل الموقع" else "🌍 ENCRYPTED ROUTING SERVERS GATEWAY",
                    color = CyberPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(viewModel.vpnServers) { server ->
                        ServerNodeRow(
                            server = server,
                            isSelected = activeServer?.id == server.id,
                            isAr = isAr,
                            onSelect = { viewModel.changeVpnServer(server) }
                        )
                    }
                }
            }
        } else {
            // Firewall Section
            Column(modifier = Modifier.fillMaxSize()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(0.5.dp, CyberPrimary.copy(0.2f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isAr) "🛡️ الجدار الناري المحلي النشط" else "🛡️ FIREWALL DROP RULES",
                            color = CyberPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isAr)
                                "قم بقطع إرسال واستقبال حزم الإنترنت لأي تطبيق مثبت مشبوه لحضر محاولات الاختراق تماماً."
                                else "Halt background egress threads. Instantly prevent suspicious sideload packages from sending user packets.",
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(apps) { app ->
                        val isBlocked = appsBlocked.contains(app.appName)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = CyberBgCard,
                            border = BorderStroke(1.dp, if (isBlocked) CyberError.copy(0.5f) else Color.Gray.copy(0.1f)),
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (isBlocked) {
                                    viewModel.blockedAppsFromInternet.value = appsBlocked - app.appName
                                } else {
                                    viewModel.blockedAppsFromInternet.value = appsBlocked + app.appName
                                }
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = if (isBlocked) Icons.Default.Block else Icons.Default.Check,
                                        contentDescription = "Status",
                                        tint = if (isBlocked) CyberError else CyberTertiary
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(text = app.appName, color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(text = app.packageName, color = CyberTextSecondary, fontSize = 10.sp, maxLines = 1)
                                    }
                                }

                                Checkbox(
                                    checked = isBlocked,
                                    onCheckedChange = { checked ->
                                        if (checked == true) {
                                            viewModel.blockedAppsFromInternet.value = appsBlocked + app.appName
                                        } else {
                                            viewModel.blockedAppsFromInternet.value = appsBlocked - app.appName
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = CyberError,
                                        uncheckedColor = Color.Gray
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpeedGaugeCard(
    title: String,
    speed: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        border = BorderStroke(0.5.dp, color.copy(0.3f)),
        colors = CardDefaults.cardColors(containerColor = CyberBgCard),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(text = speed, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = title, color = CyberTextSecondary, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun ServerNodeRow(
    server: VpnServer,
    isSelected: Boolean,
    isAr: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(10.dp),
        color = CyberBgCard,
        border = BorderStroke(1.dp, if (isSelected) CyberPrimary else Color.Gray.copy(0.1f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = server.flagEmoji, fontSize = 24.sp)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = if (isAr) server.countryNameAr else server.countryNameEn,
                        color = CyberTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SOCKS Proxy IP: ${server.ipAddress}",
                        color = CyberTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = CyberPrimary,
                    unselectedColor = Color.Gray
                )
            )
        }
    }
}
