package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val achievements by viewModel.achievements.collectAsState()
    val context = LocalContext.current

    var activeTab by remember { mutableStateOf("coder") } // "coder" or "goals"
    
    // Code builder state
    var selectedScriptService by remember { mutableStateOf("network") } // "network", "files", "spy"
    var generatedCodeText by remember { mutableStateOf("") }

    LaunchedEffect(selectedScriptService) {
        generatedCodeText = viewModel.generatePythonSecurityScript(selectedScriptService)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberBgCard, RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            Button(
                onClick = { activeTab = "coder" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "coder") CyberPrimary else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAr) "مولد سكربتات الحماية" else "Python Cyber Builder",
                    color = if (activeTab == "coder") CyberBg else CyberTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = { activeTab = "goals" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "goals") CyberPrimary else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAr) "إنجازات الدعم الفني" else "Achievements",
                    color = if (activeTab == "goals") CyberBg else CyberTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == "coder") {
            // Python customized script writer console
            Column(modifier = Modifier.fillMaxSize()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(0.5.dp, CyberPrimary.copy(0.2f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isAr) "🐍 مولد سكربتات بايثون الذكية" else "🐍 CUSTOM PYTHON PROTECT MODULES",
                            color = CyberPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isAr)
                                "قم باختيار قالب ونوع السكربت لتوليد كود بايثون آمن معزول تماماً ومجهل لإعادة تطبيقه على خادومك."
                                else "Compile obfuscated client-side defense modules written in clean Python. Safeguard routing gateways or prevent filesystem encryption.",
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                // Selector chips
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val templateMapping = listOf(
                        Triple("network", "حراسة ARP للشبكة", "ARP Watchdog"),
                        Triple("files", "مراقب برمجيات الفدية", "Ransom Sentinel"),
                        Triple("spy", "تصفية عمليات التجسس", "Spy Sweeper")
                    )

                    templateMapping.forEach { mapping ->
                        FilterChip(
                            selected = selectedScriptService == mapping.first,
                            onClick = { selectedScriptService = mapping.first },
                            label = { Text(text = if (isAr) mapping.second else mapping.third, fontSize = 11.sp) }
                        )
                    }
                }

                // Obfuscated code viewport container
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFF030307), RoundedCornerShape(8.dp))
                        .border(1.dp, Color.Gray.copy(0.15f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            Text(
                                text = generatedCodeText,
                                color = Color(0xFF00FF41),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        Toast.makeText(context, if (isAr) "تم نسخ الكود الحافظة بنجاح!" else "Source code copied to workspace clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberBg, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = if (isAr) "نسخ الكود البرمجي لحافظة للجهاز" else "Obfuscate & Copy Payload", color = CyberBg, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // Gamified achievements core list with checkpoints
            Column(modifier = Modifier.fillMaxSize()) {
                val securedCount = achievements.count { it.isUnlocked }
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(1.dp, CyberTertiary.copy(0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isAr) "🛡️ نقاط فحص حمو المكتملة" else "🛡️ COMPLETED MILESTONES",
                                color = CyberTertiary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAr) "لقد قمت بحماية الهاتف بنسبة $securedCount/${achievements.size}" else "Safeguarded metrics total score: $securedCount/${achievements.size}",
                                color = CyberTextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        
                        Text(
                            text = "${(securedCount * 250)} XP",
                            color = CyberTertiary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(achievements) { ach ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (ach.isUnlocked) CyberTertiary.copy(0.04f) else CyberBgCard),
                            border = BorderStroke(1.dp, if (ach.isUnlocked) CyberTertiary.copy(0.3f) else Color.Gray.copy(0.1f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (ach.isUnlocked) Icons.Default.WorkspacePremium else Icons.Default.Lock,
                                    contentDescription = "Badge",
                                    tint = if (ach.isUnlocked) CyberTertiary else Color.Gray.copy(0.5f),
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = if (isAr) ach.badgeNameAr else ach.badgeNameEn,
                                        color = CyberTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isAr) ach.descTextAr else ach.descTextEn,
                                        color = CyberTextSecondary,
                                        fontSize = 11.sp
                                    )
                                    if (ach.isUnlocked) {
                                        Text(
                                            text = if (isAr) "مكتمل ومؤمّن +250 XP" else "Unlocked Metric +250 XP",
                                            color = CyberTertiary,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
