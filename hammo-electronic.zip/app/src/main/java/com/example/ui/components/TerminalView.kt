package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberTerminalBg
import com.example.ui.theme.MatrixGreen
import com.example.viewmodel.SecurityViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val logs by viewModel.terminalLogs.collectAsState()
    var input by remember { mutableStateOf("") }
    val lazyListState = rememberLazyListState()

    // Automatically scroll to bottom when command logs expand
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            lazyListState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp)
    ) {
        // Upper terminal description info card
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberTerminalBg),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .border(1.dp, MatrixGreen.copy(0.4f), RoundedCornerShape(8.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (isAr) "📟 طرفية الأوامر الأمنية لحمو" else "📟 HAMO ADVANCED SECURITY SHELL",
                    color = MatrixGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = if (isAr)
                        "أدخل 'help' لعرض دليل الأوامر (فحص الملفات، الجدار الناري، قطع الاتصال الطارئ)."
                        else "Type 'help' to audit system threads, engage stateful firewalling, or bypass VPN.",
                    color = Color.slateGray(),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Terminal text canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(CyberTerminalBg, RoundedCornerShape(8.dp))
                .border(1.dp, Color.Gray.copy(0.15f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(logs) { log ->
                    Text(
                        text = log,
                        color = if (log.startsWith(">")) CyberPrimary else MatrixGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        fontWeight = if (log.startsWith(">")) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Input shell line
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = input,
                onValueChange = { input = it },
                placeholder = {
                    Text(
                        text = if (isAr) "أدخل أمر الحماية هنا..." else "Enter binary order...",
                        color = Color.slateGray().copy(0.5f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, CyberPrimary.copy(0.3f), RoundedCornerShape(12.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = CyberTerminalBg,
                    unfocusedContainerColor = CyberTerminalBg,
                    focusedTextColor = MatrixGreen,
                    unfocusedTextColor = MatrixGreen,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (input.isNotBlank()) {
                        viewModel.executeTerminalCommand(input)
                        input = ""
                    }
                }),
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (input.isNotBlank()) {
                        viewModel.executeTerminalCommand(input)
                        input = ""
                    }
                },
                colors = IconButtonDefaults.iconButtonColors(containerColor = CyberPrimary)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Execute Command",
                    tint = CyberBg
                )
            }
        }
    }
}

// Minimal Color extension helper
private fun Color.Companion.slateGray(): Color = Color(0xFF94A3B8)
