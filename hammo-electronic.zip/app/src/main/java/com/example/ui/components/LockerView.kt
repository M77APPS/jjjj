package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VaultFile
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@Composable
fun LockerView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val isConfigured by viewModel.isVaultConfigured.collectAsState()
    val isUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val failedAttempts by viewModel.failedPinAttempts.collectAsState()
    val photoTaken by viewModel.intruderPhotoTaken.collectAsState()

    var pinInput by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp)
    ) {
        if (!isConfigured) {
            // First time PIN setup
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LockOpen,
                    contentDescription = "Lock",
                    tint = CyberPrimary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isAr) "تأسيس الخزنة الرقمية المشفرة" else "Setup High-Security Locker Pin",
                    color = CyberTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (isAr) "أدخل رمز مكون من 6 أرقام على الأقل للوصول للخزنة في المستقبل" else "Establish a robust 6-digit passcode to seal your records",
                    color = CyberTextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(16.dp)
                )

                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { if (it.length <= 8) pinInput = it },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp),
                    placeholder = { Text(text = "Passcode", color = CyberTextSecondary.copy(0.5f)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberTextSecondary.copy(0.3f),
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (pinInput.length >= 6) {
                            viewModel.setupVaultPin(pinInput)
                            pinInput = ""
                        } else {
                            pinMessage = if (isAr) "الرمز ضعيف، يجب أن يكون 6 أرقام كحد أدنى." else "PIN holds weak security density. Set at least 6 digits."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.width(180.dp)
                ) {
                    Text(text = if (isAr) "حفظ الرمز 🔐" else "Secure PIN 🔐", color = CyberBg, fontWeight = FontWeight.Bold)
                }

                if (pinMessage.isNotEmpty()) {
                    Text(text = pinMessage, color = CyberError, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        } else if (!isUnlocked) {
            // PIN Verification Entry
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (failedAttempts >= 3) Icons.Default.GppBad else Icons.Default.Lock,
                    contentDescription = "Lock State",
                    tint = if (failedAttempts >= 3) CyberError else CyberSecondary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isAr) "أدخل كلمة الخزنة لفك التشفير" else "Input Vault Key Decryption Profile",
                    color = CyberTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = if (isAr) "محاولات الوصول المسموحة معززة بخواص التقاط المهاجمين" else "Access attempts are monitored. Intruders are snap-tracked",
                    color = CyberTextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                if (failedAttempts > 0) {
                    Text(
                        text = if (isAr) "عدد المحاولات الخاطئة: $failedAttempts/3" else "Failed checks logged: $failedAttempts/3",
                        color = CyberError,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                if (photoTaken) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberError.copy(0.12f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                            .border(1.dp, CyberError.copy(0.5f), RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = if (isAr) "⚠️ تم تفعيل الكاميرا والتقاط صورة المتسلل بنجاح!" else "⚠️ Intruder biometric captured & written to safe logs!",
                            color = CyberError,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { if (it.length <= 8) pinInput = it },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberTextSecondary.copy(0.3f),
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val verified = viewModel.verifyVaultPin(pinInput)
                        if (verified) {
                            pinInput = ""
                            pinMessage = ""
                        } else {
                            pinInput = ""
                            pinMessage = if (isAr) "كلمة المرور خاطئة!" else "Access Key Invalid!"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = if (isAr) "فك تشفير الملفات 🔓" else "Decrypt Vault Archive 🔓", color = CyberTextPrimary, fontWeight = FontWeight.Bold)
                }

                if (pinMessage.isNotEmpty()) {
                    Text(text = pinMessage, color = CyberError, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        } else {
            // Decrypted Locker Dashboard View
            VaultContentDashboard(viewModel, isAr)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultContentDashboard(viewModel: SecurityViewModel, isAr: Boolean) {
    val vaultItems by viewModel.vaultFiles.collectAsState()
    
    var fileName by remember { mutableStateOf("") }
    var fileContent by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("Image") } // "Image", "Video", "Document"
    
    var isAddOpen by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = if (isAr) "ألبوم الخزنة المحمي AES-256" else "AES-256 Cloud Vault", color = CyberTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(text = if (isAr) "إجمالي الملفات المشفرة: ${vaultItems.size}" else "Encrypted blocks: ${vaultItems.size}", color = CyberTextSecondary, fontSize = 12.sp)
            }
            
            IconButton(
                onClick = { viewModel.lockVault() },
                colors = IconButtonDefaults.iconButtonColors(containerColor = CyberBgCard)
            ) {
                Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock", tint = CyberError)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Expandable insertion sheet
        if (isAddOpen) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, CyberPrimary.copy(0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = if (isAr) "إضافة ملف مشفر جديد" else "Append Encrypted Record", color = CyberTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedTextField(
                        value = fileName,
                        onValueChange = { fileName = it },
                        label = { Text(text = if (isAr) "اسم الملف" else "File Identifier") },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = CyberTextPrimary)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedTextField(
                        value = fileContent,
                        onValueChange = { fileContent = it },
                        label = { Text(text = if (isAr) "محتوى الملف" else "File Data") },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = CyberTextPrimary)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val types = listOf("Image", "Video", "Document")
                        types.forEach { t ->
                            FilterChip(
                                selected = selectedType == t,
                                onClick = { selectedType = t },
                                label = { Text(text = t) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { isAddOpen = false }) {
                            Text(text = if (isAr) "إلغاء" else "Cancel", color = CyberTextSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (fileName.isNotBlank() && fileContent.isNotBlank()) {
                                    viewModel.addNewVaultFile(fileName, fileContent, selectedType)
                                    fileName = ""
                                    fileContent = ""
                                    isAddOpen = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberTertiary)
                        ) {
                            Text(text = if (isAr) "تشفير وحفظ 🔒" else "Seal Record 🔒", color = CyberBg)
                        }
                    }
                }
            }
        } else {
            Button(
                onClick = { isAddOpen = true },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add", tint = CyberBg)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = if (isAr) "تشفير وحماية ملف جديد " else "Secure New File File", color = CyberBg, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // List of encrypted locker items
        if (vaultItems.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(imageVector = Icons.Default.FolderZip, contentDescription = "Zip", tint = CyberTextSecondary.copy(0.4f), modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = if (isAr) "الخزنة فارغة كلياً." else "Locker is currently empty.", color = CyberTextSecondary)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vaultItems) { file ->
                    VaultCardItem(file, isAr, onDelete = { viewModel.deleteVaultFile(file.id) })
                }
            }
        }
    }
}

@Composable
fun VaultCardItem(file: VaultFile, isAr: Boolean, onDelete: () -> Unit) {
    Card(
        border = BorderStroke(1.dp, CyberPrimary.copy(0.2f)),
        colors = CardDefaults.cardColors(containerColor = CyberBgCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when(file.fileType) {
                        "Image" -> Icons.Default.Image
                        "Video" -> Icons.Default.VideoLibrary
                        else -> Icons.Default.Description
                    },
                    contentDescription = "File icon",
                    tint = CyberPrimary
                )
                
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = CyberError.copy(0.7f), modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = file.originalName,
                color = CyberTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = if (isAr) "قيمة مشفرة: SEC-AES-256" else "Encoded: SEC_AES_256",
                color = CyberSecondary,
                fontSize = 10.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Hex: ...${file.encryptedContentHex.takeLast(10)}",
                color = CyberTextSecondary,
                fontSize = 10.sp,
                maxLines = 1,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
    }
}
