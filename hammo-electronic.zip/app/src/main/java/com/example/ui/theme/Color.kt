package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBg = Color(0xFF060B18) // Extremely deep dark royal navy
val CyberBgCard = Color(0xFF0F172A) // Dark slate card background
val CyberPrimary = Color(0xFF00D4FF) // Neon Cyan
val CyberSecondary = Color(0xFF9D4EDD) // Neon Purple
val CyberTertiary = Color(0xFF10B981) // Neon Green (Safe)
val CyberError = Color(0xFFEF4444) // Neon Red (Danger)
val CyberWarning = Color(0xFFF59E0B) // Neon Orange/Amber (Moderate)
val CyberTextPrimary = Color(0xFFF8FAFC) // Near white text
val CyberTextSecondary = Color(0xFF94A3B8) // Muted slate gray text
val CyberAccent = Color(0xFF38BDF8) // Bright Sky Blue
val CyberTerminalBg = Color(0xFF05050A) // Console-like deep black
val MatrixGreen = Color(0xFF00FF41) // Classic terminal matrix green

