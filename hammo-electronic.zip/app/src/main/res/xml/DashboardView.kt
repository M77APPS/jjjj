package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel
import androidx.compose.ui.Alignment

@Composable
fun DashboardView(viewModel: SecurityViewModel, onSelectMenu: (String) -> Unit) {
    val isAr by viewModel.isArabic.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val scanProgress by viewModel.scanProgress.collectAsState()
    val scanTarget by viewModel.currentScanningTarget.collectAsState()
    
    val dangerScore by viewModel.dangerScorePercent.collectAsState()
    val apps by viewModel.scannedApps.collectAsState()
    val logs by viewModel.scanLogs.collectAsState()
    val cves by viewModel.detectedCVEs.collectAsState()

    val isVpnOn by viewModel.isVpnConnected.collectAsState()
    val vpnServer by viewModel.selectedVpnServer.collectAsState()
    val virtualIp by viewModel.virtualIpAddress.collectAsState()

    val lastAudit = logs.firstOrNull()

    // Scanning rotation loading animation
    val infiniteTransition = rememberInfiniteTransition()
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper Shield Indicator Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(1.dp, if (dangerScore > 50) CyberError else if (dangerScore > 15) CyberWarning else CyberTertiary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(72.dp)
                    ) {
                        // Dynamic glowing circular gradient border
                        CircularProgressIndicator(
                            progress = { if (isScanning) scanProgress else (100 - dangerScore) / 100f },
                            modifier = Modifier.fillMaxSize(),
                            color = if (dangerScore > 50) CyberError else if (dangerScore > 15) CyberWarning else CyberTertiary,
                            strokeWidth = 6.dp,
                            trackColor = Color.Gray.copy(0.12f)
                        )
                        
                        Icon(
                            imageVector = if (dangerScore > 50) Icons.Default.Warning 
                                          else if (dangerScore > 15) Icons.Default.Warning 
                                          else Icons.Default.CheckCircle,
                            contentDescription = "Shield State",
                            tint = if (dangerScore > 50) CyberError else if (dangerScore > 15) CyberWarning else CyberTertiary,
                            modifier = Modifier
                                .size(36.dp)
                                .rotate(if (isScanning) angle else 0f)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = if (isScanning) {
                                if (isAr) "جاري الفحص النشط..." else "Scanning Threat Files..."
                            } else {
                                if (dangerScore > 50) {
                                    if (isAr) "⚠️ خطر: جهازك غير محمي!" else "⚠️ CRITICAL BREACHES LOGGED"
                                } else if (dangerScore > 15) {
                                    if (isAr) "⚠️ تحذير: يوصى ببدء إصلاح" else "⚠️ CAUTION STATE CONFIRMED"
                                } else {
                                    if (isAr) "🛡️ جهازك آمن تماماً" else "🛡️ SYSTEM AUDITED & IMMUNE"
                                }
                            },
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )

                        Text(
                            text = if (isScanning) "${(scanProgress * 100).toInt()}% - $scanTarget"
                                   else {
                                       if (isAr) "مستوى تهديد الأجهزة: $dangerScore% | الفحص الأخير: ${lastAudit?.timestamp?.let { java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(it)) } ?: "لا يوجد"}"
                                       else "Firmware threat index: $dangerScore% | last check: ${lastAudit?.timestamp?.let { java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(it)) } ?: "Never"}"
                                   },
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Diagnostic quick indices cards row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricIndicatorCard(
                    title = if (isAr) "التطبيقات الخطرة" else "Risk Apps",
                    value = if (isScanning) "..." else apps.count { it.riskRating == RiskLevel.DANGER }.toString(),
                    color = CyberError,
                    icon = Icons.Default.Widgets,
                    modifier = Modifier.weight(1f)
                )

                MetricIndicatorCard(
                    title = if (isAr) "ثغرات النظام 2026" else "CVE Vulnerabilities",
                    value = if (isScanning) "..." else cves.size.toString(),
                    color = CyberWarning,
                    icon = Icons.Default.BugReport,
                    modifier = Modifier.weight(1f)
                )

                MetricIndicatorCard(
                    title = if (isAr) "حامي الشبكة" else "Net Proxy",
                    value = if (isVpnOn) "ON" else "OFF",
                    color = if (isVpnOn) CyberTertiary else CyberSecondary,
                    icon = Icons.Default.NetworkWifi,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // VPN Network gateway diagnostics card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberPrimary.copy(0.15f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = CyberBgCard)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isAr) "🌐 معايير وحالة الشبكة اللاسلكية" else "🌐 WI-FI GATEWAY & ID CODES",
                            color = CyberPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (isVpnOn) CyberTertiary else CyberWarning, RoundedCornerShape(4.dp))
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = if (isAr) "عنوان IP الحقيقي:" else "Native ISP IP:", color = CyberTextSecondary, fontSize = 11.sp)
                            Text(text = viewModel.realIpAddress, color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = if (isAr) "عنوان الحماية النشط (VPN):" else "Bypassed Proxy IP:", color = CyberTextSecondary, fontSize = 11.sp)
                            Text(text = if (isVpnOn) virtualIp else (if (isAr) "غير مشفر" else "Bypassed"), color = if (isVpnOn) CyberTertiary else CyberSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (isVpnOn) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isAr) "سرية الإنزال: GCM-256" else "Secure SOCKS Tunnel active",
                                color = CyberTextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${vpnServer?.flagEmoji} ${if (isAr) vpnServer?.countryNameAr else vpnServer?.countryNameEn}",
                                color = CyberPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Main Threat Audit Scan button
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = { viewModel.triggerSystemScan() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (dangerScore > 50) CyberError else CyberPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = CyberBg, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = if (isAr) "جاري التحليل..." else "Compiling Nodes...", color = CyberBg, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.Launch, contentDescription = "Scan", tint = CyberBg)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = if (isAr) "بدء الفحص الأمني الشامل" else "ACTIVATE THREAT SCRIPTS AUDIT", color = CyberBg, fontWeight = FontWeight.Bold)
                    }
                }

                if (!isScanning && dangerScore > 10) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { viewModel.fixAllVulnerabilities() },
                        border = BorderStroke(1.dp, CyberTertiary),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberTertiary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Build, contentDescription = "Fix", tint = CyberTertiary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = if (isAr) "إصلاح وعزل الكل بضغطة واحدة" else "EXECUTE ONE-CLICK MITIGATION REPAIR")
                    }
                }
            }
        }

        // List of discovered CVE system vulnerabilities if scanned
        if (cves.isNotEmpty() && !isScanning) {
            item {
                Text(
                    text = if (isAr) "📌 ثغرات أجهزة 2026/2027 المكتشفة" else "📌 DETECTED SYSTEM EXPLOITS (2026/2027)",
                    color = CyberError,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            items(cves) { cve ->
                CveVulnerabilityCard(cve, isAr)
            }
        }
    }
}

@Composable
fun MetricIndicatorCard(
    title: String,
    value: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        border = BorderStroke(0.5.dp, color.copy(0.3f)),
        colors = CardDefaults.cardColors(containerColor = CyberBgCard)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(16.dp))
                Text(text = value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = title, color = CyberTextSecondary, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable
fun CveVulnerabilityCard(cve: CVEItem, isAr: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberBgCard.copy(0.9f)),
        border = BorderStroke(1.dp, CyberError.copy(0.3f)),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = cve.code,
                    color = CyberError,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
                
                Surface(
                    color = CyberError.copy(0.12f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = cve.severity.name,
                        color = CyberError,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isAr) cve.threatNameAr else cve.threatNameEn,
                color = CyberTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = if (isAr) "تأثير على: ${cve.affectedSystemAr}" else "Impact on: ${cve.affectedSystemEn}",
                color = CyberTextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Text(
                text = if (isAr) cve.descriptionAr else cve.descriptionEn,
                color = CyberTextSecondary.copy(0.8f),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Mitigation advisory
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberPrimary.copy(0.06f), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        text = if (isAr) "🛡️ نصائح حمو الأمنية للإصلاح:" else "🛡️ Remediation Advisory:",
                        color = CyberPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isAr) cve.mitigationAr else cve.mitigationEn,
                        color = CyberTextPrimary,
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}
