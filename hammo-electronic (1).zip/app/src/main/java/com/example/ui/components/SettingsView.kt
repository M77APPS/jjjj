package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val isSilentShield by viewModel.isSilentShieldActive.collectAsState()
    val rawProtectionLevel by viewModel.protectionLevel.collectAsState()
    val isStealth by viewModel.isStealthModeActive.collectAsState()
    val isYt by viewModel.isSubscribedToYoutube.collectAsState()
    val isTg by viewModel.isSubscribedToTelegram.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(1.dp, CyberPrimary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "⚙️ إعدادات الصرح الأمني 2027" else "⚙️ Core Armor Controls 2027",
                        color = CyberPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isAr) 
                            "تحكم في مستوى تشفير الجهاز وقنوات التحقق والتنبيه من الاختراق." 
                            else "Adjust advanced cryptography gates, silent telemetry filters, and lock-screen bypasses.",
                        color = CyberTextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Language and Notifications Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(0.5.dp, Color.Gray.copy(0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "العامة والترجمة" else "General & Localization",
                        color = CyberSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Language switch row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = if (isAr) "اللغة العربية" else "Arabic Language Interface", color = CyberTextPrimary, fontSize = 13.sp)
                            Text(text = if (isAr) "تبديل واجهة العرض للغة العربية الفصحى" else "Switch default application locale to Arabic", color = CyberTextSecondary, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isAr,
                            onCheckedChange = { viewModel.setArabicLanguage(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberPrimary)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Silent Shield switch row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = if (isAr) "الدرع الصامت النشط" else "Silent Back-channel Shield", color = CyberTextPrimary, fontSize = 13.sp)
                            Text(text = if (isAr) "وضع ذكي لحظر تتبع الحزم بدون إشعارات مزعجة" else "Drop background exploit payloads without displaying warnings", color = CyberTextSecondary, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isSilentShield,
                            onCheckedChange = { viewModel.isSilentShieldActive.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberPrimary)
                        )
                    }
                }
            }
        }

        // Dynamic Protection Level
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(0.5.dp, Color.Gray.copy(0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "🔐 مستوى الحماية التكتيكي" else "🔐 Tactical Defense Grade",
                        color = CyberPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    val protectionLevels = listOf("LOW", "MEDIUM", "HIGH")
                    protectionLevels.forEach { level ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                val label = when (level) {
                                    "LOW" -> if (isAr) "حماية عادية (متوسطة)" else "Standard Shield (Basic Checkpoint)"
                                    "MEDIUM" -> if (isAr) "حماية مفرطة (تطبيق القانون)" else "Proactive Patrol (Aggressive Behavioral)"
                                    else -> if (isAr) "قفل مشدد (معايير عسكرية صارمة)" else "Military Lockdown (Zero-Tolerance Active)"
                                }
                                val desc = when (level) {
                                    "LOW" -> if (isAr) "يفحص تواقيع التطبيقات فقط" else "Only monitors active static signatures"
                                    "MEDIUM" -> if (isAr) "يحلل سلوك البرامج في الخلفية" else "Adds real-time process monitoring scans"
                                    else -> if (isAr) "حظر كامل للأدوات غير الموقعة والروابط الخارجية" else "Full cryptographic block on unverified packages"
                                }
                                Text(text = label, color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = desc, color = CyberTextSecondary, fontSize = 11.sp)
                            }
                            RadioButton(
                                selected = rawProtectionLevel == level,
                                onClick = { viewModel.protectionLevel.value = level },
                                colors = RadioButtonDefaults.colors(selectedColor = CyberPrimary)
                            )
                        }
                    }
                }
            }
        }

        // Stealth Mode Settings
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(0.5.dp, Color.Gray.copy(0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "🕵️ وضع التخفي التام" else "🕵️ Advanced Stealth Mode",
                        color = CyberSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = if (isAr) "تفعيل وضع الظل" else "Enable Shadow Execution", color = CyberTextPrimary, fontSize = 13.sp)
                            Text(
                                text = if (isAr) 
                                    "تخفي التطبيق كليا من المشغل والإشعارات. يستمر العمل بصمت تام وتوجيه التحذيرات للهواتف المربوطة فقط."
                                    else "App operates under disguised system process. Logs are encrypted and hidden from common explorer audits.", 
                                color = CyberTextSecondary, 
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isStealth,
                            onCheckedChange = { viewModel.isStealthModeActive.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberSecondary)
                        )
                    }
                }
            }
        }

        // Gating & Verification Simulation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(1.dp, CyberError.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "📡 محاكي حالة التراخيص والاشتراكات" else "📡 Subscription Gate Simulator",
                        color = CyberError,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text(
                        text = if (isAr) 
                            "أثبت حظر التطبيق لنفسه فوراً عند إلغاء اشتراكات يوتيوب وتيليجرام حمو الإلكتروني كما طلبت." 
                            else "Verify requirement 'if they unsubscribe, the app locks itself' using these interactive live simulation toggles.",
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Youtube Switch row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Subscriptions, contentDescription = "Youtube", tint = Color(0xFFFF0000), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = if (isAr) "اشتراك يوتيوب (Hamoelectronic)" else "YouTube subscribed (Hamoelectronic)", color = CyberTextPrimary, fontSize = 13.sp)
                        }
                        Switch(
                            checked = isYt,
                            onCheckedChange = { viewModel.isSubscribedToYoutube.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberTertiary, uncheckedThumbColor = CyberError)
                        )
                    }

                    // Telegram Switch row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Chat, contentDescription = "Telegram", tint = Color(0xFF24A1DE), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = if (isAr) "اشتراك تيليجرام (M77APPS_Support)" else "Telegram subscribed (M77APPS_Support)", color = CyberTextPrimary, fontSize = 13.sp)
                        }
                        Switch(
                            checked = isTg,
                            onCheckedChange = { viewModel.isSubscribedToTelegram.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberTertiary, uncheckedThumbColor = CyberError)
                        )
                    }
                }
            }
        }
    }
}
