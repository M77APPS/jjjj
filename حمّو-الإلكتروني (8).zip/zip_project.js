const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('Starting project archiving...');

// Install adm-zip on-the-fly to execute packaging
try {
    require.resolve('adm-zip');
} catch (e) {
    console.log('Installing adm-zip dependency...');
    execSync('npm install adm-zip --no-save', { stdio: 'inherit' });
}

const AdmZip = require('adm-zip');
const zip = new AdmZip();

const exclude = [
    '.gradle',
    '.idea',
    'build',
    'app/build',
    'node_modules',
    'hemo_silent_shield.zip',
    '.build-outputs'
];

function isExcluded(filePath) {
    const relative = path.relative(__dirname, filePath);
    return exclude.some(ex => {
        return relative === ex || relative.startsWith(ex + path.sep);
    });
}

function addDirectory(localDir, zipDir) {
    const list = fs.readdirSync(localDir);
    list.forEach(file => {
        const localPath = path.join(localDir, file);
        const zipPath = zipDir ? path.join(zipDir, file) : file;
        
        if (isExcluded(localPath)) {
            return;
        }
        
        const stat = fs.statSync(localPath);
        if (stat.isDirectory()) {
            addDirectory(localPath, zipPath);
        } else {
            console.log(`Adding file to ZIP: ${zipPath}`);
            const data = fs.readFileSync(localPath);
            zip.addFile(zipPath.replace(/\\/g, '/'), data);
        }
    });
}

addDirectory(__dirname, '');
zip.writeZip('hemo_silent_shield.zip');
console.log('Successfully generated hemo_silent_shield.zip! 📦');
