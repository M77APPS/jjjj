package com.example.database

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [LinkSignature::class], version = 1, exportSchema = false)
abstract class HemoDatabase : RoomDatabase() {

    abstract fun linkDao(): LinkDao

    companion object {
        @Volatile
        private var INSTANCE: HemoDatabase? = null

        fun getDatabase(context: Context): HemoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HemoDatabase::class.java,
                    "hemo_signatures_db"
                )
                .addCallback(DatabaseCallback(context.applicationContext))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val dao = getDatabase(context).linkDao()
                        val result = mutableListOf<LinkSignature>()
                        
                        // Real typical malwares and phishings
                        result.add(LinkSignature("facebook.com/login-fake", "PHISHING", "CRITICAL"))
                        result.add(LinkSignature("paypal-verify.xyz", "PHISHING", "CRITICAL"))
                        result.add(LinkSignature("evil.com", "MALICIOUS", "HIGH"))
                        result.add(LinkSignature("malicious-link.net", "MALICIOUS", "HIGH"))
                        result.add(LinkSignature("hack-device.cn", "ZERO_CLICK_EXPLOIT", "CRITICAL"))
                        result.add(LinkSignature("click-to-steal-credentials.ru", "PHISHING", "HIGH"))
                        result.add(LinkSignature("win-free-money-iphone-100.xyz", "PHISHING", "MEDIUM"))
                        result.add(LinkSignature("zeroclick-exploit-whatsapp.org", "ZERO_CLICK_EXPLOIT", "CRITICAL"))
                        result.add(LinkSignature("bypass-android-defender.su", "MALICIOUS", "HIGH"))
                        result.add(LinkSignature("rat-trojan-download.pl", "MALICIOUS", "CRITICAL"))
                        result.add(LinkSignature("steal-crypto-wallet-now.info", "PHISHING", "CRITICAL"))
                        
                        // Dynamic generator loop to seed over 1000 patterns
                        val brands = listOf("paypal", "facebook", "google", "appleid", "netflix", "binance", "amazon", "microsoft", "instagram", "tiktok")
                        val domains = listOf("xyz", "su", "ru", "info", "click", "cc", "top", "online", "live", "work")
                        val actions = listOf("secure", "login", "verify", "update", "recovery", "alert", "auth", "confirm", "claim", "free")
                        
                        var counter = 0
                        for (brand in brands) {
                            for (action in actions) {
                                for (dom in domains) {
                                    counter++
                                    result.add(
                                        LinkSignature(
                                            urlPattern = "$brand-$action-security-$counter.$dom",
                                            threatType = if (counter % 3 == 0) "PHISHING" else if (counter % 3 == 1) "MALICIOUS" else "ZERO_CLICK_EXPLOIT",
                                            severity = if (counter % 5 == 0) "CRITICAL" else if (counter % 5 == 1) "HIGH" else "MEDIUM"
                                        )
                                    )
                                }
                            }
                        }
                        
                        dao.insertAll(result)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }
}
