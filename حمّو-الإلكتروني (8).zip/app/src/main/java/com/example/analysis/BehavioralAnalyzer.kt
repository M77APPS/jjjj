package com.example.analysis

import android.content.Context
import android.os.Build
import android.util.Log
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.database.HemoDatabase
import com.example.database.LinkSignature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class ScanResult {
    object SAFE : ScanResult()
    data class MALICIOUS(val threatType: String) : ScanResult()
    object PHISHING : ScanResult()
    object ZERO_CLICK_EXPLOIT : ScanResult()
    object UNKNOWN : ScanResult()
}

class BehavioralAnalyzer(private val context: Context) {

    private val TAG = "BehavioralAnalyzer"

    // OkHttpClient with restricted 3-second limits and followRedirects = false
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()

    /**
     * Conducts non-intrusive HEAD scans + network redirection checks + isolates in sandboxed WebView.
     */
    suspend fun analyze(url: String): ScanResult = withContext(Dispatchers.IO) {
        val cleanUrl = url.trim().lowercase()
        val formattedUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            "https://$url"
        } else {
            url
        }

        // أ. فحص التوقيعات المحلية من Room
        try {
            val db = HemoDatabase.getDatabase(context)
            val matchingSignatures = db.linkDao().findMatchingSignatures(cleanUrl)
            if (matchingSignatures.isNotEmpty()) {
                val bestMatch = matchingSignatures.first()
                Log.d(TAG, "Local Room signature matched: ${bestMatch.urlPattern}")
                return@withContext ScanResult.MALICIOUS(bestMatch.threatType)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed searching local signatures db", e)
        }

        // أ-2. فحص Google Safe Browsing API لو المفتاح متوفر
        val safeBrowsingKey = try { com.example.BuildConfig.SAFE_BROWSING_API_KEY } catch (e: Exception) { "" }
        if (safeBrowsingKey.isNotEmpty() && !safeBrowsingKey.contains("YOUR_")) {
            try {
                val request = com.example.data.SafeBrowsingRequest(
                    client = com.example.data.ClientInfo("HemoSilentShield", "2.0"),
                    threatInfo = com.example.data.ThreatInfo(
                        threatTypes = listOf("MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"),
                        platformTypes = listOf("ANDROID", "ANY_PLATFORM"),
                        threatEntryTypes = listOf("URL"),
                        threatEntries = listOf(com.example.data.ThreatEntry(formattedUrl))
                    )
                )
                val response = com.example.data.RetrofitClient.safeBrowsingService.findThreatMatches(safeBrowsingKey, request)
                if (response.matches?.isNotEmpty() == true) {
                    val match = response.matches!!.first()
                    Log.d("BehavioralAnalyzer", "Google Safe Browsing flagged URL: ${match.threatType}")
                    if (match.threatType.contains("MALWARE") || match.threatType.contains("HARMFUL")) {
                        return@withContext ScanResult.MALICIOUS(match.threatType)
                    } else {
                        return@withContext ScanResult.PHISHING
                    }
                }
            } catch (e: Exception) {
                Log.e("BehavioralAnalyzer", "Google Safe Browsing API check failed: ${e.localizedMessage}")
            }
        }

        // ب. إرسال طلب HEAD باستخدام OkHttpClient (مهلة 3 ثوانٍ، no redirects)
        var responseCode = -1
        var contentType = ""
        var locationHeader = ""
        var contentLength: Long = -1

        try {
            val headRequest = Request.Builder()
                .url(formattedUrl)
                .head()
                .header("User-Agent", "HemoSilentShield/2.0 (Mobile Sandbox Client)")
                .build()

            client.newCall(headRequest).execute().use { response ->
                responseCode = response.code
                contentType = response.header("Content-Type")?.lowercase() ?: ""
                locationHeader = response.header("Location") ?: ""
                contentLength = response.body?.contentLength() ?: -1L
            }
            Log.d(TAG, "Behavioral Scan - Code: $responseCode, Type: $contentType, Redirect Location: $locationHeader, Size: $contentLength")
        } catch (e: Exception) {
            Log.e(TAG, "Behavioral network analyzer HEAD request unreachable: ${e.localizedMessage}")
        }

        // ج. إذا اشتبه في Zero-Click أو ثغرات حديثة (مثلاً محاولة تنفيذ كود أو حجم صغير جداً مع سلوك غريب) ترفع ZERO_CLICK_EXPLOIT
        val zeroClickPatterns = listOf(
            ".php?cmd=", ".sh", ".py", "/etc/", "system32", "cmd.exe", "powershell", "wget", "curl",
            "cve-2023", "cve-2024", "cve-2025", "cve-2026", "exploit", "shellcode", "rce", "follina", "msdt",
            "zero-click", "pegasus", "spyware", "backdoor", "remote-access", "trojan"
        )
        val isZeroClickUrlPattern = zeroClickPatterns.any { cleanUrl.contains(it) }
        val isSuspiciousTinySize = contentLength in 1..150 && (contentType.contains("javascript") || contentType.contains("application"))

        if (isZeroClickUrlPattern || isSuspiciousTinySize) {
            Log.d(TAG, "Zero-click or Exploit Indicators flagged! pattern: $isZeroClickUrlPattern, tinySize: $isSuspiciousTinySize")
            return@withContext ScanResult.ZERO_CLICK_EXPLOIT
        }

        // د. فحص تصيد متقدم لاستهداف خدمات شهيرة (مثل انستا باي، فوادفون كاش، بنوك وصالح العرب)
        val financialPhishingPatterns = listOf(
            "instapay", "fawry", "vodafone-cash", "cib-online", "banquemisr", "banque-misr",
            "nationalbankofegypt", "ahli-bank", "egyptpost", "we-pay", "orange-money", "etisalat-cash",
            "paymob", "valu", "insta-pay", "fawry-portal", "vodafonecash"
        )
        val socialPhishingPatterns = listOf(
            "whatsapp-bonus", "facebook-login", "instagram-update", "netflix-free", "snapchat-premium",
            "telegram-gift", "pubg-uc-free", "tiktok-coins", "free-gems", "bonus-egypt"
        )
        val isPhishingTarget = financialPhishingPatterns.any { cleanUrl.contains(it) && !cleanUrl.contains("instapay.eg") && !cleanUrl.contains("fawry.com") && !cleanUrl.contains("vodafone.com.eg") } ||
                               socialPhishingPatterns.any { cleanUrl.contains(it) }

        if (isPhishingTarget) {
            Log.d(TAG, "Advanced Phishing Spoofing flagged: $cleanUrl")
            return@withContext ScanResult.PHISHING
        }

        // هـ. Inspect redirects for phishing behaviors
        if (responseCode in 300..308 && locationHeader.isNotEmpty()) {
            val cleanLocation = locationHeader.lowercase()
            if (cleanLocation.contains("login") || cleanLocation.contains("signin") || cleanLocation.contains("verify") || cleanLocation.contains("verification") || cleanLocation.contains("banking") || cleanLocation.contains("instapay")) {
                return@withContext ScanResult.PHISHING
            }
        }

        // و. Silent APK downloads or risky executables
        val maliciousExtensions = listOf(".apk", ".exe", ".msi", ".bat", ".cmd", ".ps1", ".vbs", ".scr", ".lnk", ".hta", ".jar")
        if (contentType.contains("application/vnd.android.package-archive") || maliciousExtensions.any { cleanUrl.endsWith(it) || cleanUrl.contains(it + "?") }) {
            return@withContext ScanResult.MALICIOUS("SILENT_DRIVEBY_DOWNLOAD")
        }

        // د. استخدام WebView في وضع آمن (JavaScript false, DOM storage false, allow file access false) لعزل الصفحة كفحص إضافي
        try {
            withContext(Dispatchers.Main) {
                runWebViewIsolationSanity(formattedUrl)
            }
        } catch (e: Exception) {
            Log.e(TAG, "WebView virtual deployment exception", e)
        }

        return@withContext ScanResult.SAFE
    }

    /**
     * Initializes structural isolated safe settings inside standard WebViews
     * with javascript and file system accesses completely disabled.
     */
    private fun runWebViewIsolationSanity(url: String) {
        try {
            val sandboxWebView = WebView(context).apply {
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                        return true // Keep trapped inside sandbox
                    }
                }
                settings.apply {
                    javaScriptEnabled = false // Block cross-site scripting
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        mediaPlaybackRequiresUserGesture = true
                    }
                }
            }
            // Trigger pre-emptive load inside detached virtual container
            sandboxWebView.loadUrl(url)
            Log.d(TAG, "Isolating web renderer sandbox successfully initialized for $url")
        } catch (e: Exception) {
            Log.e(TAG, "WebView container initialization bypassed", e)
        }
    }
}
