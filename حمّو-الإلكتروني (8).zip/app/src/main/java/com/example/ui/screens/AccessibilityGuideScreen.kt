package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.HemoAccessibilityService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilityGuideScreen(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val neonGreen = Color(0xFF00FF41)
    val neonCyan = Color(0xFF00E5FF)
    val neonRed = Color(0xFFFE2C55)
    val cyberDarkBg = Color(0xFF07090E)
    val glassCardBg = Color(0xFF111622)
    val glassBorder = Color(0xFF1E293B)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(cyberDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Icon & Title
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(neonGreen.copy(alpha = 0.12f), CircleShape)
                .border(2.dp, neonGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Restricted Settings Info",
                tint = neonGreen,
                modifier = Modifier.size(36.dp)
            )
        }

        Text(
            text = "دليل حكيم لتشغيل إمكانيات الوصول 🦾🛡️",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Text(
            text = "عشان أندرويد 13 و 14 بيمنعوا تفعيل خدمات الإتاحة وبيعتبروها 'إعدادات مقيدة' (Restricted Settings) لحماية الأمان، لازم تسمح للتطبيق يدويًا الأول عشان حمو يقدر يحميك من الروابط الخبيثة في الواتساب وفيسبوك بنجاح!",
            fontSize = 12.sp,
            color = Color.LightGray,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp,
            modifier = Modifier.fillMaxWidth()
        )

        Divider(color = glassBorder, modifier = Modifier.padding(vertical = 4.dp))

        // Step-by-Step Interactive Cards
        Text(
            text = "الخطوات البسيطة للحل في ثواني 📲",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = neonCyan,
            modifier = Modifier.align(Alignment.End)
        )

        // Step 1 Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(neonGreen.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("١", color = neonGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "افتح إعدادات التطبيق",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "دوس على الزرار اللي تحت عشان تفتح صفحة معلومات تطبيق 'الدرع الصامت' في إعدادات تليفونك.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                }
                                context.startActivity(intent)
                                Toast.makeText(context, "دوس على الـ 3 نقط فوق على اليمين واختار السماح بالإعدادات المقيدة", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "فشل فتح إعدادات التطبيق: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("روح لإعدادات التطبيق ⚙️", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Step 2 Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(neonGreen.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("٢", color = neonGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "فك القيد عن التطبيق",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "لما تفتح صفحة الإعدادات، بص فوق على اليمين هتلاقي ٣ نقط (أو علامة تعجب ℹ️)، اضغط عليها واختار 'السماح بالإعدادات المقيدة' (Allow restricted settings). الحظر اتفك كده خلاص يا بطل!",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        textAlign = TextAlign.Right
                    )
                }
            }
        }

        // Step 3 Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(neonGreen.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("٣", color = neonGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "شغّل الخدمة الحية لحمو",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "ارجع لإعدادات الجهاز ومنها 'إمكانية الوصول' (Accessibility) > 'الخدمات المثبّتة' (Installed apps)، وشغّل خدمة 'Hemo Silent Shield' فوراً لتبدأ الحماية الحية.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "فشل فتح إعدادات إمكانية الوصول: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("شغل الخدمة الحالية ⚡", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        // Battery Optimization Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, neonCyan.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(neonCyan.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = "Battery", tint = neonCyan, modifier = Modifier.size(14.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "استثناء موفر البطارية (مستحسن)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "تليفونك بيقفل التطبيقات بالخلفية عشان يوفر بطارية. عشان كود الحماية يفضل صاحي وحارس تلميح الروابط دائمًا بدون انقطاع، اسمح لحمو يتخطى توفير طاقة جهازك يا صديقي.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            try {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                    context.startActivity(intent)
                                } else {
                                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                    context.startActivity(intent)
                                }
                            } catch (e: Exception) {
                                try {
                                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                    context.startActivity(intent)
                                } catch (ex: Exception) {
                                    Toast.makeText(context, "يرجى الإذن من خيارات البطارية بالنظام يدوياً.", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = neonCyan.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("استثناء توفير الطاقة 🔋", color = neonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Large Dismiss/Complete Actions Button
        Button(
            onClick = onDismiss,
            colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(
                text = "فهمت الخطوات، افتح اللوحة 🦾🛡️",
                color = Color.Black,
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )
        }
    }
}
