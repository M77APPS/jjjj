package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ThreatLog

@Composable
fun DashboardScreenContent(
    context: Context,
    isVpnActive: Boolean,
    blockedUrlsCount: Int,
    safetyScore: Int,
    logs: List<ThreatLog>,
    liveEvents: List<String>,
    onToggleVpnRequested: (Boolean) -> Unit,
    onClearLogsClicked: () -> Unit,
    onShowAccessibilityGuide: () -> Unit
) {
    val neonGreen = Color(0xFF00FF88)
    val neonRed = Color(0xFFFF3333)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    var showActivationWizard by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "الدرع الصامت الذكي 🦾",
                    color = neonGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "غرفة عمليات حمو 🛡️",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(if (isVpnActive) neonGreen else neonRed, CircleShape)
                    .border(2.dp, Color.Black, CircleShape)
            )
        }

        // Circular dynamic health gauge (Military Monospace data)
        Box(
            modifier = Modifier
                .size(175.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.4f))
                .border(2.dp, neonGreen.copy(alpha = 0.3f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$safetyScore%",
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    color = if (safetyScore > 75) neonGreen else if (safetyScore > 40) neonCyan else neonRed,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "مستوى أمان جهازك يا صاحبي",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Silent Shield activation panel with LARGE interactive trigger button
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, if (isVpnActive) neonGreen.copy(alpha = 0.4f) else glassBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (isVpnActive) neonGreen.copy(alpha = 0.1f) else Color.Gray.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Shield Guard",
                            tint = if (isVpnActive) neonGreen else Color.Gray,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isVpnActive) "الدرع الصامت شغال وبطل ويحميك بالخلفية 🟢" else "الدرع الصامت واقف! تليفونك في خطر 🔴",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Text(
                            text = "الفحص السلوكي حارس تليفونك، بيلقط روابط التصيد ويمنع الهكرز والبرامج الخبيثة تسحب بياناتك.",
                            fontSize = 10.sp,
                            color = Color.Gray,
                            lineHeight = 14.sp
                        )
                    }
                }

                // Highly visible BIG action button to summon the wizard
                Button(
                    onClick = { showActivationWizard = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isVpnActive) neonCyan else neonGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Config Mode",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isVpnActive) "ظبط صلاحيات الدرع" else "🛡️ شغّل الدرع الصامت يا حمو 🦾",
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Live stats panel (Military Fonts)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(1.dp, glassBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("الروابط اللي فحصناها", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${logs.size}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(1.dp, glassBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("روابط حظرناها 🔐", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(4.dp))
                     val realBlockedCount = blockedUrlsCount + logs.count { it.threatType != "SAFE" }
                     Text(
                        text = "$realBlockedCount",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = neonRed,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // MonitoringLiveScreen.kt integration (Flow of last 5 activities)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF090E1A)),
            border = BorderStroke(1.dp, glassBorder.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "📺 اللوحة الحية - أحدث الأنشطة (الوقت الفعلي)",
                    color = neonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                if (liveEvents.isEmpty()) {
                    Text(
                        text = "بانتظار وقوع أحداث نظام الشبكة والخلفية...",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        liveEvents.forEach { event ->
                            val isW = event.contains("🔴") || event.contains("حظر") || event.contains("فاشل")
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(if (isW) neonRed else neonGreen, CircleShape)
                                )
                                Text(
                                    text = event,
                                    fontSize = 10.5.sp,
                                    color = Color.LightGray,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Right
                                )
                            }
                        }
                    }
                }
            }
        }

        // Accessibility activation step-by-step assistant
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "⚙️ ازاي تشغل خدمة الإتاحة عشان حمو يحميك؟",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "عشان حمو يلقط أي رابط خبيث في ثانية ويحميك، اتبّع الخطوات دي وشغّل الخدمة:",
                    fontSize = 10.sp,
                    color = Color.LightGray,
                    lineHeight = 14.sp
                )
                Divider(color = glassBorder)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("1. دوس على الزرار اللي تحت عشان تفتح إعدادات الإتاحة.", fontSize = 9.5.sp, color = Color.LightGray)
                    Text("2. افتح الخدمات المتنقلة أو 'Installed Services'.", fontSize = 9.5.sp, color = Color.LightGray)
                    Text("3. اختر خدمة 'Hemo Silent Shield'.", fontSize = 9.5.sp, color = Color.LightGray)
                    Text("4. شغل المفتاح واستمتع بحماية فوق الخيال طول الوقت!", fontSize = 9.5.sp, color = Color.LightGray)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = {
                        onShowAccessibilityGuide()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = glassBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("شغل خدمة الإتاحة لحمو 📲", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Interactive Full Overlay Security Activation Wizard Dialog
    if (showActivationWizard) {
        AlertDialog(
            onDismissRequest = { showActivationWizard = false },
            title = {
                Text(
                    text = "مركز حمو لتنشيط الحماية الشاملة 🦾🛡️",
                    color = neonGreen,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "ظبط مستويات درع حمو عشان نراقب السلوكيات ونقوم بفحص الروابط ثانية بثانية لحمايتك:",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    // Step 1: VPN Local DNS Tunnel
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
                        border = BorderStroke(1.dp, if (isVpnActive) neonGreen.copy(alpha = 0.4f) else glassBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "VPN",
                                tint = if (isVpnActive) neonGreen else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("شغل عزل الرسايل والمواقع (VPN)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("بيحظر وينضف الروابط الخبيثة تلقائياً بذكاء", color = Color.Gray, fontSize = 9.sp)
                            }
                            Switch(
                                checked = isVpnActive,
                                onCheckedChange = { active ->
                                    onToggleVpnRequested(active)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = neonGreen,
                                    checkedTrackColor = neonGreen.copy(alpha = 0.3f)
                                )
                            )
                        }
                    }

                    // Step 2: Accessibility link interceptor
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
                        border = BorderStroke(1.dp, glassBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Accessibility",
                                tint = neonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("خدمة الإتاحة وقراية الروابط", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("بتلقط وتفحص أي رابط يظهر قدامك في أي تطبيق ثاني", color = Color.Gray, fontSize = 9.sp)
                            }
                            Button(
                                onClick = {
                                    onShowAccessibilityGuide()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = glassBorder),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("شغلها 📲", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Step 3: Energy optimization exclusions
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
                        border = BorderStroke(1.dp, glassBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Battery",
                                tint = neonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("استثناء توفير طاقة البطارية", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("عشان الدرع يفضل حارس جهازك بالخلفية بدون نوم", color = Color.Gray, fontSize = 9.sp)
                            }
                            Button(
                                onClick = {
                                    try {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                            context.startActivity(intent)
                                        } else {
                                            Toast.makeText(context, "إصدار جهازك لا يتطلب هذا الاستثناء يدوياً.", Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "يرجى الإذن الاستثنائي يدوياً في الخيارات المتقدمة للنظام.", Toast.LENGTH_LONG).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = glassBorder),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("استثنيها 🔋", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showActivationWizard = false },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                ) {
                    Text("كله تمام يا باشا 🦾", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            },
            containerColor = Color(0xFF0F1524),
            shape = RoundedCornerShape(16.dp)
        )
    }
}
