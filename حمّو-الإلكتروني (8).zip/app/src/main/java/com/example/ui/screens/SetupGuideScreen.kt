package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SetupGuideScreen(
    onDismiss: () -> Unit,
    onEnableVpn: () -> Unit
) {
    val context = LocalContext.current
    val neonGreen = Color(0xFF00FF88)
    val neonCyan = Color(0xFF00E5FF)
    val neonRed = Color(0xFFFF3333)
    val carbonDark = Color(0xFF0A0A0A)
    val glassCardBg = Color(0xFF131722)
    val borderGray = Color(0xFF222B3C)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(carbonDark)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Logo Title Area
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(neonGreen.copy(alpha = 0.1f), CircleShape)
                .border(2.dp, neonGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Hemo Guard Shield",
                tint = neonGreen,
                modifier = Modifier.size(32.dp)
            )
        }

        Text(
            text = "إزيك يا بطل! مرحب بيك في حمّو الإلكتروني 🛡️💪",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Text(
            text = "أنا أخوك حمو.. وتطبيقي ده معمول مخصوص عشان يحميك بجد 100% من الاختصابات والروابط الملغمة والتصيد اللي بتسرق حساباتك. عشان أندرويد ساعات بيقفل الخدمات دي رخم ورخمين، عملنا طرق بديلة عشان نضمن لك أمان فوري ومن غير الحاجة لـ Accessibility المقفولة!",
            fontSize = 11.5.sp,
            color = Color.LightGray,
            textAlign = TextAlign.Center,
            lineHeight = 17.sp,
            modifier = Modifier.fillMaxWidth()
        )

        Divider(color = borderGray, thickness = 1.dp)

        Text(
            text = "خطوات تشغيل دروع الأمان الحقيقية 👇",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = neonCyan,
            modifier = Modifier.align(Alignment.End)
        )

        // Guide 1: Clipboard Monitor Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, borderGray)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(neonGreen.copy(alpha = 0.2f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("١", color = neonGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "درع رصد الحافظة (Clipboard Radar)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "بمجرد ما تنسخ أي لينك من واتساب أو تليجرام، حمو هيلقطه في الخلفية فوراً ويبعتلك تنبيه لو كان الرابط ده نصاب أو ملغم عشان يحميك قبل ما تدخل عليه!",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
                Button(
                    onClick = {
                        Toast.makeText(context, "الرادار شغال بالخلفية وبيحميك تلقائياً يا صاحبي! ⚡", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("درع الحافظة شغال دايماً ✔️", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        // Guide 2: VPN interception Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, borderGray)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(neonCyan.copy(alpha = 0.2f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("٢", color = neonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "درع التصفح الآمن (Local VPN)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "شغّل الـ VPN المحلي بضغطة واحدة، وكل الروابط من أي متصفح هتعدي أولاً على فلتر حمو السلوكي عشان لو داخل موقع تصيد نقفله ونحميك فوراً.",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
                Button(
                    onClick = onEnableVpn,
                    colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("شغّل درع الـ VPN للمتصفح 🛡️", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        // Guide 3: Restricted Settings Workaround for Oppo/Android 13+ Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, borderGray)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(neonRed.copy(alpha = 0.15f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("٣", color = neonRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "حل مشكلة الحظر (Oppo & Android 13+)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "لو جهازك أوبو أو أي تليفون أندرويد ١٣ أو ١٤ وبيقولك 'إعدادات مقيدة' ومش عارف تفعل إمكانية الوصول للدرع، الحل سهل جداً وبسيط:\n" +
                            "١. روح لإعدادات تليفونك وافتح 'معلومات تطبيق حمّو الإلكتروني'\n" +
                            "٢. دوس على الـ ٣ نقط فوق على اليمين واختار 'السماح بالإعدادات المقيدة'\n" +
                            "٣. ارجع هنا وفعل الخدمة بكل سهولة يا غالي!",
                    color = Color.LightGray,
                    fontSize = 10.5.sp,
                    lineHeight = 15.sp
                )
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                            Toast.makeText(context, "دوس على الـ 3 نقط فوق يمين واختار 'السماح بالإعدادات المقيدة' يا غالي", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "طريقة تانية: افتح الضبط > التطبيقات > ابحث عن حمو الإلكتروني واعملها يدوي", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222F3E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("افتح إعدادات حمو لفك القيد ⚙️", color = neonGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Direct Actions Skip Button
        Button(
            onClick = onDismiss,
            colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(
                text = "جاهز يا حمو.. افتح لي لوحة التحكم الحقيقية 🦾⚡",
                color = Color.Black,
                fontWeight = FontWeight.Black,
                fontSize = 12.5.sp
            )
        }
    }
}
