package com.example.intercept

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.ui.theme.MyApplicationTheme

class InterceptActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Read URL from incoming Intent data
        val targetUri: Uri? = intent.data
        val targetUrl = targetUri?.toString() ?: ""

        if (targetUrl.isBlank()) {
            Toast.makeText(this, "الرابط فارغ أو غير صالح للاعتراض!", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setContent {
            MyApplicationTheme {
                InterceptDialogUi(
                    url = targetUrl,
                    onScanSelected = {
                        // Route client to main scanner view with payload
                        val scanIntent = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra("INTERCEPTED_URL_KEY", targetUrl)
                        }
                        startActivity(scanIntent)
                        finish()
                    },
                    onOpenDirectSelected = {
                        // Bypass protection and open directly in browser without looping back to us
                        try {
                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            val pm = packageManager
                            val resolveInfos = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                                pm.queryIntentActivities(browserIntent, android.content.pm.PackageManager.ResolveInfoFlags.of(0L))
                            } else {
                                @Suppress("DEPRECATION")
                                pm.queryIntentActivities(browserIntent, 0)
                            }
                            
                            var targetPackage: String? = null
                            for (info in resolveInfos) {
                                val pkgName = info.activityInfo.packageName
                                if (pkgName != packageName) {
                                    targetPackage = pkgName
                                    break
                                }
                            }
                            
                            if (targetPackage != null) {
                                browserIntent.setPackage(targetPackage)
                                startActivity(browserIntent)
                            } else {
                                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                startActivity(webIntent)
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this, "فشل فتح المتصفح المساعد: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                        finish()
                    },
                    onCancelSelected = {
                        finish()
                    }
                )
            }
        }
    }
}

@Composable
fun InterceptDialogUi(
    url: String,
    onScanSelected: () -> Unit,
    onOpenDirectSelected: () -> Unit,
    onCancelSelected: () -> Unit
) {
    // Cyberpunk tactical styling details
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val glassCardBg = Color(0xFF111622)
    val glassBorder = Color(0xFF1E293B)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.65f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header indicator
                Text(
                    text = "عايز تفحص الرابط ده قبل ما تفتحه؟ 🤔",
                    color = neonGreen,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Divider(color = glassBorder, thickness = 1.dp)

                Text(
                    text = "$url",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    lineHeight = 16.sp
                )

                Text(
                    text = "تطبيق حمّو الإلكتروني يقترح عليك فحص الرابط لتجنب مواقع الاصطياد وسرقة الحسابات والملفات الخبيثة.",
                    color = Color.White,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Tactical Choices Layout
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onScanSelected,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "🛡️ فحص",
                            fontWeight = FontWeight.Black,
                            color = Color.Black,
                            fontSize = 13.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onOpenDirectSelected,
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, neonRed),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = neonRed)
                    ) {
                        Text(
                            text = "⚠️ فتح مباشرة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    TextButton(
                        onClick = onCancelSelected,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "إلغاء",
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
