package com.example.intercept

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.MainActivity
import java.util.regex.Pattern

class ShareReceiverActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val intentAction = intent.action
        val intentType = intent.type

        if ((Intent.ACTION_SEND == intentAction || Intent.ACTION_SEND_MULTIPLE == intentAction) && intentType != null) {
            if (intentType.startsWith("text/")) {
                if (Intent.ACTION_SEND_MULTIPLE == intentAction) {
                    handleSharedMultipleTexts(intent)
                } else {
                    handleSharedText(intent)
                }
            }
        }
        finish()
    }

    private fun handleSharedMultipleTexts(intent: Intent) {
        val texts = intent.getStringArrayListExtra(Intent.EXTRA_TEXT)
        if (texts != null) {
            val urlPattern = Pattern.compile(
                "(https?://|www\\.)[a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-A-Za-z0-9+&@#/%=~_|]"
            )
            for (sharedText in texts) {
                if (sharedText != null) {
                    val matcher = urlPattern.matcher(sharedText)
                    if (matcher.find()) {
                        val detectedUrl = matcher.group()
                        val mainIntent = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra("INTERCEPTED_URL_KEY", detectedUrl)
                        }
                        startActivity(mainIntent)
                        Toast.makeText(this, "جاري تحويل الروابط للمعمل للفحص الآمن! 🛡️", Toast.LENGTH_SHORT).show()
                        return
                    }
                }
            }
        }
        Toast.makeText(this, "لم نجد أي روابط ويب صالحة في النصوص المشتركة!", Toast.LENGTH_LONG).show()
    }

    private fun handleSharedText(intent: Intent) {
        val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
        if (sharedText != null) {
            val urlPattern = Pattern.compile(
                "(https?://|www\\.)[a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-A-Za-z0-9+&@#/%=~_|]"
            )
            val matcher = urlPattern.matcher(sharedText)
            if (matcher.find()) {
                val detectedUrl = matcher.group()
                
                val mainIntent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("INTERCEPTED_URL_KEY", detectedUrl)
                }
                startActivity(mainIntent)
                Toast.makeText(this, "جاري تحويل الرابط للمعمل للفحص الآمن! 🛡️", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "لم نجد أي روابط ويب صالحة في النص المشترك!", Toast.LENGTH_LONG).show()
            }
        }
    }
}
