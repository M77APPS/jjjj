package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.analysis.BehavioralAnalyzer
import com.example.analysis.ScanResult
import com.example.utils.SecurityEventBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.regex.Pattern

class ClipboardMonitorService : Service() {

    private val TAG = "ClipboardMonitor"
    private val CHANNEL_ID = "hemo_clipboard_monitor_channel"
    private val NOTIFICATION_ID = 2028
    
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var clipboardManager: ClipboardManager? = null
    private var lastClipboardText: String = ""
    private val handler = Handler(Looper.getMainLooper())
    
    private val urlPattern = Pattern.compile(
        "(https?://|www\\.)[a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-A-Za-z0-9+&@#/%=~_|]"
    )

    private val checkClipboardTask = object : Runnable {
        override fun run() {
            checkClipboard()
            handler.postDelayed(this, 1500) // check every 1.5 - 2 seconds
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "ClipboardMonitorService Created")
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "ClipboardMonitorService Started")
        
        val notification = createPersistentNotification()
        startForeground(NOTIFICATION_ID, notification)
        
        handler.removeCallbacks(checkClipboardTask)
        handler.post(checkClipboardTask)
        
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "ClipboardMonitorService Destroyed")
        handler.removeCallbacks(checkClipboardTask)
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun checkClipboard() {
        try {
            val clip = clipboardManager?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0).text?.toString() ?: ""
                if (text.isNotBlank() && text != lastClipboardText) {
                    lastClipboardText = text
                    Log.d(TAG, "Clipboard changed: $text")
                    
                    val matcher = urlPattern.matcher(text)
                    if (matcher.find()) {
                        val detectedUrl = matcher.group()
                        SecurityEventBus.emitEvent("📋 لقطنا رابط عندك في الحافظة: $detectedUrl")
                        scanCopiedUrl(detectedUrl)
                    }
                }
            }
        } catch (e: Exception) {
            // Background clipboard scanning might be limited on Android 10+ when app is entirely backgrounded,
            // we catch silently as Android prevents background reading without focus.
            Log.v(TAG, "Clipboard bypass: ${e.localizedMessage}")
        }
    }

    private fun scanCopiedUrl(url: String) {
        serviceScope.launch {
            try {
                val analyzer = BehavioralAnalyzer(applicationContext)
                val scanResult = analyzer.analyze(url)
                displayScanNotification(url, scanResult)
            } catch (e: Exception) {
                Log.e(TAG, "Failed scan in service", e)
            }
        }
    }

    private fun displayScanNotification(url: String, result: ScanResult) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("INTERCEPTED_URL_KEY", url)
        }
        
        val pendingIntent = PendingIntent.getActivity(
            this,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notificationTitle: String
        val notificationText: String
        val smallIconDrawable: Int

        when (result) {
            is ScanResult.MALICIOUS -> {
                notificationTitle = "🚨 الرابط ده نار متفتحوش! (ضار)"
                notificationText = "حمو حظر الرابط ده فوراً: $url. فيه مشاكل كبيرة!"
                smallIconDrawable = android.R.drawable.stat_notify_error
            }
            is ScanResult.PHISHING -> {
                notificationTitle = "⚠️ رادار حمو لقط رابط تصيد واحتيال!"
                notificationText = "الرابط ده بيحاول يسرق بياناتك: $url"
                smallIconDrawable = android.R.drawable.stat_sys_warning
            }
            is ScanResult.ZERO_CLICK_EXPLOIT -> {
                notificationTitle = "💀 رابط ثغرة خبيث جداً! (Zero-Click)"
                notificationText = "بيحاول ينفذ أكواد على جهازك: $url"
                smallIconDrawable = android.R.drawable.stat_notify_error
            }
            else -> {
                notificationTitle = "🛡️ الرابط المنسوخ شكله أمان"
                notificationText = "حمّو فحص الرابط ده وكل حاجة تمام: $url"
                smallIconDrawable = android.R.drawable.ic_lock_idle_lock
            }
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(notificationTitle)
            .setContentText(notificationText)
            .setSmallIcon(smallIconDrawable)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(3002, notification)
    }

    private fun createPersistentNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📋 رادار الحافظة شغال وجاهز")
            .setContentText("حمو بيحرس جهازك من أي روابط بتنسخها بالكامل بالخلفية 🛡️")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "📋 رصد روابط الحافظة والنسخ",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات حمّو الإلكتروني عند رصد وحظر روابط الحافظة الضارة."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
