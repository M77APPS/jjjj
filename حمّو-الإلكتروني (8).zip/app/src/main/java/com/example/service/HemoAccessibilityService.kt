package com.example.service

import android.annotation.SuppressLint
import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import android.provider.Settings
import com.example.analysis.BehavioralAnalyzer
import com.example.analysis.ScanResult
import com.example.data.AppDatabase
import com.example.data.SecurityRepository
import com.example.data.ThreatLog
import kotlinx.coroutines.*
import java.util.regex.Pattern

class HemoAccessibilityService : AccessibilityService() {

    private val TAG = "HemoAccessibility"
    private val CHANNEL_ID = "hemo_accessibility_alerts"
    private val NOTIFICATION_ID = 2027

    private val urlPattern = Pattern.compile(
        "(https?://|www\\.)[a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-A-Za-z0-9+&@#/%=~_|]"
    )

    private var lastScannedUrl = ""
    private var lastScannedTime: Long = 0
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        Log.d(TAG, "HemoAccessibilityService bound and connected successfully")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceRunning = false
        serviceScope.cancel()
        Log.d(TAG, "HemoAccessibilityService unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val rootNode = rootInActiveWindow ?: return
        scanNodeForUrls(rootNode)
    }

    private fun scanNodeForUrls(node: AccessibilityNodeInfo?) {
        if (node == null) return

        val textsToScan = mutableListOf<String>()
        node.text?.let { textsToScan.add(it.toString()) }
        node.contentDescription?.let { textsToScan.add(it.toString()) }

        for (text in textsToScan) {
            val matcher = urlPattern.matcher(text)
            if (matcher.find()) {
                val foundUrl = matcher.group()
                val currentTime = System.currentTimeMillis()
                
                if (foundUrl != lastScannedUrl || (currentTime - lastScannedTime) > 7000) {
                    lastScannedUrl = foundUrl
                    lastScannedTime = currentTime
                    Log.d(TAG, "Dynamic scanner discovered link on activity screen: $foundUrl")
                    
                    com.example.utils.SecurityEventBus.emitEvent("🔍 لقطنا رابط جديد على شاشتك: $foundUrl")
                    performBackgroundUrlAnalysis(foundUrl)
                }
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                scanNodeForUrls(child)
            }
        }
    }

    private fun performBackgroundUrlAnalysis(url: String) {
        serviceScope.launch {
            try {
                val analyzer = BehavioralAnalyzer(applicationContext)
                val scanResult = analyzer.analyze(url)
                
                // If it is malicious or suspicious, register in threat logs and alert the user immediately!
                if (scanResult !is ScanResult.SAFE && scanResult !is ScanResult.UNKNOWN) {
                    val riskTypeStr = when (scanResult) {
                        is ScanResult.PHISHING -> "PHISHING"
                        is ScanResult.ZERO_CLICK_EXPLOIT -> "ZERO_CLICK_EXPLOIT"
                        is ScanResult.MALICIOUS -> "MALICIOUS"
                        else -> "SUSPICIOUS"
                    }
                    val threatCategoryLocal = when (scanResult) {
                        is ScanResult.PHISHING -> "صفحة تصيد واحتيالية (Phishing)"
                        is ScanResult.ZERO_CLICK_EXPLOIT -> "اختراق ذو نقرة صفرية (Zero-Click)"
                        is ScanResult.MALICIOUS -> "رابط ضار / برمجيات خبيثة (${scanResult.threatType})"
                        else -> "رابط مشبوه"
                    }
                    
                    LocalVpnService.incrementBlockedCount()
                    com.example.utils.SecurityEventBus.emitEvent("🔴 تم رصد وحظر رابط خبيث على الشاشة: $url")

                    // Log threat in local database
                    try {
                        val db = AppDatabase.getDatabase(applicationContext)
                        val log = ThreatLog(
                            url = url,
                            threatType = riskTypeStr,
                            actionTaken = "تم عزل الاتصال وتنبيه البطل فوراً عبر الإشعارات 🛡️",
                            timestamp = System.currentTimeMillis(),
                            securityScore = if (riskTypeStr == "ZERO_CLICK_EXPLOIT") 5 else 10,
                            riskType = riskTypeStr,
                            threatCategory = threatCategoryLocal,
                            analysisLog = "تم رصد هذا الرابط أثناء مروره على الشاشة في تطبيق آخر وننصحك بعدم فتحه نهائياً."
                        )
                        db.threatLogDao().insertLog(log)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed logging to DB in accessibility loop", e)
                    }
                    
                    sendThreatAlertNotification(url, scanResult)
                } else {
                    // Send quiet safety check event
                    com.example.utils.SecurityEventBus.emitEvent("🟢 محمي: فحصنا الرابط اللي ظهر على الشاشة وطلع آمن ونظيف سلوكياً!")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error analyzing background accessibility link", e)
            }
        }
    }

    @SuppressLint("NotificationPermission")
    private fun sendThreatAlertNotification(url: String, result: ScanResult) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("INTERCEPTED_URL_KEY", url)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notificationTitle: String
        val notificationText: String
        val smallIconDrawable: Int

        when (result) {
            is ScanResult.MALICIOUS -> {
                notificationTitle = "🚨 رابط ضار جداً ومخرب على شاشتك!"
                notificationText = "حمو لقط رابط ثغرة/ملف ضار: $url. ابعد عنه ومتفتحوش!"
                smallIconDrawable = android.R.drawable.stat_notify_error
            }
            is ScanResult.PHISHING -> {
                notificationTitle = "⚠️ رادار حمو لقط صفحة تصيد واحتيال!"
                notificationText = "الرابط ده بيحاول يسرق حساباتك فورا: $url. لا تسجل دخولك!"
                smallIconDrawable = android.R.drawable.stat_sys_warning
            }
            is ScanResult.ZERO_CLICK_EXPLOIT -> {
                notificationTitle = "💀 تحذير قصوى: رابط اختراق نقرة صفرية!"
                notificationText = "بيحاول يستغل ثغرات ويتحكم بجهازك: $url"
                smallIconDrawable = android.R.drawable.stat_notify_error
            }
            else -> {
                notificationTitle = "⚠️ رابط مشبوه على شاشتك"
                notificationText = "حمو الإلكتروني بيمصحك فحص الرابط ده: $url"
                smallIconDrawable = android.R.drawable.ic_dialog_info
            }
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(notificationTitle)
            .setContentText(notificationText)
            .setSmallIcon(smallIconDrawable)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onInterrupt() {
        Log.e(TAG, "Accessibility passive scanning service interrupted")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "🔗 تنبيهات الروابط المكتشفة تلقائياً",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة تنبيهات حمّو الإلكتروني لإرسال تحذيرات عند اكتشاف روابط التصيد في التطبيقات الأخرى."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        var isServiceRunning = false

        fun isAccessibilityServiceEnabled(context: Context): Boolean {
            val expectedComponentName = android.content.ComponentName(context, HemoAccessibilityService::class.java)
            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = android.text.TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServicesSetting)
            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()
                val enabledService = android.content.ComponentName.unflattenFromString(componentNameString)
                if (enabledService != null && enabledService == expectedComponentName) {
                    return true
                }
            }
            return false
        }
    }
}
