const fs = require('fs');
const content = fs.readFileSync('debug.keystore.base64', 'utf8').trim();
const buffer = Buffer.from(content, 'base64');
fs.writeFileSync('app/debug.keystore', buffer);
console.log('Successfully written debug.keystore relative');
