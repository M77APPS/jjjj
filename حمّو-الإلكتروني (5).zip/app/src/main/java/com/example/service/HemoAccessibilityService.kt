package com.example.service

import android.annotation.SuppressLint
import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import java.util.regex.Pattern

class HemoAccessibilityService : AccessibilityService() {

    private val TAG = "HemoAccessibility"
    private val CHANNEL_ID = "hemo_accessibility_alerts"
    private val NOTIFICATION_ID = 2027

    private val urlPattern = Pattern.compile(
        "(https?://|www\\.)[a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-A-Za-z0-9+&@#/%=~_|]"
    )

    private var lastScannedUrl = ""
    private var lastScannedTime: Long = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val rootNode = rootInActiveWindow ?: return
        scanNodeForUrls(rootNode)
    }

    private fun scanNodeForUrls(node: AccessibilityNodeInfo?) {
        if (node == null) return

        val textsToScan = mutableListOf<String>()
        node.text?.let { textsToScan.add(it.toString()) }
        node.contentDescription?.let { textsToScan.add(it.toString()) }

        for (text in textsToScan) {
            val matcher = urlPattern.matcher(text)
            if (matcher.find()) {
                val foundUrl = matcher.group()
                val currentTime = System.currentTimeMillis()
                
                if (foundUrl != lastScannedUrl || (currentTime - lastScannedTime) > 5000) {
                    lastScannedUrl = foundUrl
                    lastScannedTime = currentTime
                    Log.d(TAG, "Dynamic scanner discovered link on activity screen: $foundUrl")
                    
                    com.example.utils.SecurityEventBus.emitEvent("🔍 رصد رابط بالخلفية عبر خدمة الإتاحة: $foundUrl")
                    sendDirectThreatNotification(foundUrl)
                }
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                scanNodeForUrls(child)
            }
        }
    }

    @SuppressLint("NotificationPermission")
    private fun sendDirectThreatNotification(url: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("INTERCEPTED_URL_KEY", url)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🔗 حمو لقط رابط جديد! ")
            .setContentText("لقينا رابط جديد: $url. اضغط هنا فوراً يا زميلي عشان نفحصه ونحميك!")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onInterrupt() {
        Log.e(TAG, "Accessibility passive scanning service interrupted")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "🔗 تنبيهات الروابط المكتشفة تلقائياً",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة تنبيهات حمّو الإلكتروني لإرسال تحذيرات عند اكتشاف روابط التصيد في التطبيقات الأخرى."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
