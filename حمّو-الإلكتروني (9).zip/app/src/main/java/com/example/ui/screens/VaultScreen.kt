package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SecurityViewModel
import com.example.data.VaultEntry
import java.io.File
import androidx.compose.ui.platform.LocalContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreenContent(
    viewModel: SecurityViewModel,
    context: Context
) {
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    val prefs = remember { context.getSharedPreferences("hemo_prefs", Context.MODE_PRIVATE) }
    var masterPin by remember { mutableStateOf(prefs.getString("vault_master_pin", "") ?: "") }
    var isVaultUnlocked by remember { mutableStateOf(false) }
    var setupPinInput by remember { mutableStateOf("") }
    var setupPinConfirmInput by remember { mutableStateOf("") }
    var enterPinInput by remember { mutableStateOf("") }

    val vaultEntries by viewModel.vaultEntries.collectAsState()
    val totpCode by viewModel.totpCode.collectAsState()
    val totpProgress by viewModel.totpProgress.collectAsState()
    val totpSecondsLeft by viewModel.totpSecondsLeft.collectAsState()

    var secretTitle by remember { mutableStateOf("") }
    var secretContent by remember { mutableStateOf("") }
    var secretPin by remember { mutableStateOf("") }

    var decryptingEntry by remember { mutableStateOf<VaultEntry?>(null) }
    var inputDecryptPin by remember { mutableStateOf("") }
    var revealedContentDialogText by remember { mutableStateOf<String?>(null) }

    // SAF Launchers for Import and Export
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        uri?.let {
            viewModel.exportVaultToUri(context, it) { success ->
                if (success) {
                    Toast.makeText(context, "تمت عملية تصدير الخزنة المشفرة بنجاح! 📤", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "فشل تصدير بيانات الخزنة.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            viewModel.importVaultFromUri(context, it) { success, msg ->
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun triggerBiometricPrompt() {
        val executor = androidx.core.content.ContextCompat.getMainExecutor(context)
        try {
            val biometricPrompt = androidx.biometric.BiometricPrompt(
                context as androidx.fragment.app.FragmentActivity,
                executor,
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        Toast.makeText(context, "صاحب الهاتف: $errString", Toast.LENGTH_SHORT).show()
                    }

                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        isVaultUnlocked = true
                        Toast.makeText(context, "تم فتح الخزنة السيبرانية بنجاح! 🔓", Toast.LENGTH_SHORT).show()
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        Toast.makeText(context, "فشلت المحاولة الحيوية، حاول مجدداً.", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            val promptInfo = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("الخزنة الحديدية لحمو 🧬")
                .setSubtitle("قم برصد بصمة الإصبع أو الوجه لفتح مخزنك العسكري")
                .setNegativeButtonText("إلغاء")
                .build()

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "مستشعر البصمة غير متوفر أو غير مهيأ. الرجاء استخدام الرمز الاحتياطي (PIN) للدخول الآمن.", Toast.LENGTH_LONG).show()
        }
    }

    if (!isVaultUnlocked) {
        if (masterPin.isEmpty()) {
            // First time PIN setup UI
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF080C14))
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Setup Vault Pin",
                    tint = neonCyan,
                    modifier = Modifier
                        .size(80.dp)
                        .border(2.dp, neonCyan, CircleShape)
                        .padding(16.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "تنشيط الخزنة: إنشاء الرمز الاحتياطي الأولى 🔐",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "لحمايتك، لا توجد كلمات مرور افتراضية أو أبواب خلفية. يرجى إنشاء قفل احتياطي قوي لا يقل عن 6 خانات (أرقام أو حروف) لتتمتع بتشفير كامل لبياناتك.",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = setupPinInput,
                    onValueChange = { setupPinInput = it },
                    label = { Text("أدخل الرمز الاحتياطي الجديد (6+ خانات)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = neonCyan,
                        unfocusedBorderColor = glassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = setupPinConfirmInput,
                    onValueChange = { setupPinConfirmInput = it },
                    label = { Text("أكد كتابة الرمز الاحتياطي") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = neonCyan,
                        unfocusedBorderColor = glassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (setupPinInput.length < 6) {
                            Toast.makeText(context, "الرمز الاحتياطي يجب أن يتكون من 6 خانات أو أكثر لمزيد من الأمان!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (setupPinInput != setupPinConfirmInput) {
                            Toast.makeText(context, "الرمزان غير متطابقين، يرجى التأكيد بشكل صحيح.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        prefs.edit().putString("vault_master_pin", setupPinInput).apply()
                        masterPin = setupPinInput
                        setupPinInput = ""
                        setupPinConfirmInput = ""
                        isVaultUnlocked = true
                        Toast.makeText(context, "تم إنشاء الرمز بنجاح! الخزنة السيبرانية أصبحت جاهزة ومفعلة 🦾", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("تأكيد وإنشاء رمز PIN الاحتياطي ✔️", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        } else {
            // Biometric Locked Layer with Military Warning Design
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF080C14))
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked Vault",
                    tint = neonRed,
                    modifier = Modifier
                        .size(80.dp)
                        .border(2.dp, neonRed, CircleShape)
                        .padding(16.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "طلب مصادقة الخزنة السيبرانية 🔐",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "الخزنة الحديدية مغلقة ومعزولة عسكرياً عبر بروتوكولات حمو الإلكترونية لمنع قرصنة البيانات وسرقة رموز الهويات الحساسة.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    onClick = { triggerBiometricPrompt() },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "🔑 فك القفل الحيوي الآمن (بصمة / وجه)",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Custom Backup master PIN unlock
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF121824)),
                    border = BorderStroke(1.dp, glassBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "استخدام الرمز الاحتياطي (PIN/الباسورد)",
                            color = neonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = enterPinInput,
                            onValueChange = { enterPinInput = it },
                            label = { Text("أدخل رمز PIN الاحتياطي الخاص بك (6+ خانات)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = neonCyan,
                                unfocusedBorderColor = glassBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Button(
                            onClick = {
                                if (enterPinInput == masterPin) {
                                    isVaultUnlocked = true
                                    enterPinInput = ""
                                    Toast.makeText(context, "مرحبا بك! تم فتح الخزنة السيبرانية بنجاح! 🦾", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "الرمز الاحتياطي المدخل خاطئ، يرجى المحاولة مرة أخرى!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("دخول بالرمز الاحتياطي 🔓", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    } else {
        // Vault Unlocked UI
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "منظم الخزينة السيبرانية 🔐",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Button(
                    onClick = { isVaultUnlocked = false },
                    colors = ButtonDefaults.buttonColors(containerColor = neonRed),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("قفل الخزنة", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = "تدرع تام عبر معيار AES-256-GCM المشفر بمفاتيح غير قابلة للنسخ في Android Keystore مع توليد رموز الأمان المتغيرة تلقائياً.",
                fontSize = 11.sp,
                color = Color.Gray,
                lineHeight = 16.sp
            )

            // TOTP Authenticator Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F131E)),
                border = BorderStroke(1.dp, glassBorder)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).background(neonCyan, CircleShape))
                            Text("مُولد الرموز ثنائية الأمان (TOTP) ⏳", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text("مؤقت: ${totpSecondsLeft}s", color = neonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    LinearProgressIndicator(
                        progress = { totpProgress },
                        color = neonCyan,
                        trackColor = Color.DarkGray,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = totpCode,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = neonGreen,
                        textAlign = TextAlign.Center,
                        letterSpacing = 2.sp
                    )

                    Text("رمز الأمان المؤقت للمصادقة الدفاعية والتأكيد التلقائي للأجهزة", color = Color.Gray, fontSize = 10.sp)
                }
            }

            // Export and Import Tools Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1220)),
                border = BorderStroke(1.dp, glassBorder)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "خيارات النقل الاحتياطي (النسخ الاحتياطي المشفر) 📤",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { exportLauncher.launch("hemo_vault_secure_export.enc") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("تصدير النسخة المشفرة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { importLauncher.launch(arrayOf("application/octet-stream", "*/*")) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("استيراد النسخة المشفرة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Add new secret item card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("حفظ وتشفير محتوى جديد بالخزنة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    OutlinedTextField(
                        value = secretTitle,
                        onValueChange = { secretTitle = it },
                        label = { Text("عنوان المحتوى (مثال: حساب المحفظة البنكية)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = neonGreen,
                            unfocusedBorderColor = glassBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    OutlinedTextField(
                        value = secretContent,
                        onValueChange = { secretContent = it },
                        label = { Text("المحتوى السري لعزله وتشفيره وتخزينه") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = neonGreen,
                            unfocusedBorderColor = glassBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    OutlinedTextField(
                        value = secretPin,
                        onValueChange = { secretPin = it },
                        label = { Text("رمز PIN اختياري لمصادقة فك التشفير الثنائية") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = neonGreen,
                            unfocusedBorderColor = glassBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Button(
                        onClick = {
                            if (secretTitle.isBlank() || secretContent.isBlank()) {
                                Toast.makeText(context, "برجاء إدخال عنوان ومحتوى السر أولاً!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.encryptAndSaveVaultEntry(secretTitle, secretContent, secretPin)
                            secretTitle = ""
                            secretContent = ""
                            secretPin = ""
                            Toast.makeText(context, "تم الحفظ والتشفير عسكرياً بالخزنة السيبرانية 🛡️", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("تشفير AES وحفظ بالخزنة 🔒", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Stored Protected Entries List
            Text(
                text = "المدخلات السيبرانية المحمية بالدرع (${vaultEntries.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            if (vaultEntries.isEmpty()) {
                Text(
                    text = "الخزنة الحديدية فارغة تماماً ولا تحتفظ برخص أو بيانات هويات حالياً.",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    vaultEntries.forEach { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(glassCardBg, RoundedCornerShape(10.dp))
                                .border(1.dp, glassBorder, RoundedCornerShape(10.dp))
                                .padding(12.dp)
                                .clickable {
                                    decryptingEntry = entry
                                },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                                val dateStr = try { sdf.format(java.util.Date(entry.timestamp)) } catch (e: Exception) { entry.timestamp.toString() }
                                Text(entry.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("تاريخ الحفظ: $dateStr", fontSize = 9.sp, color = Color.Gray)
                                Text("محتوى مشفر (AES-256): ${entry.encryptedContent.take(20)}...", fontSize = 10.sp, color = neonGreen)
                            }
                            IconButton(onClick = { viewModel.deleteVaultEntry(entry) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = neonRed)
                            }
                        }
                    }
                }
            }
        }
    }

    // Interactive Dialog prompts
    if (decryptingEntry != null) {
        AlertDialog(
            onDismissRequest = {
                decryptingEntry = null
                inputDecryptPin = ""
            },
            title = { Text("مصادقة فك التشفير العسكرية 🛡️", color = neonGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (decryptingEntry?.pin != null) 
                            "يتطلب هذا الملف PIN المقترح لفك القفل ثنائياً. الرجاء إدخاله للمرور:" 
                            else "اضغط زر التأكيد لفك تشفير وعرض المحتوى السري المنسق تلقائياً:",
                        color = Color.White,
                        fontSize = 12.sp
                    )

                    if (decryptingEntry?.pin != null) {
                        OutlinedTextField(
                            value = inputDecryptPin,
                            onValueChange = { inputDecryptPin = it },
                            label = { Text("رمز PIN ثنائي") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = neonGreen,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val entry = decryptingEntry ?: return@Button
                        viewModel.decryptVaultEntry(entry, inputDecryptPin) { plainText ->
                            if (plainText == "PIN_ERR") {
                                revealedContentDialogText = "فشل المصادقة: رمز الـ PIN الثنائي المقارن خاطئ!"
                            } else if (plainText == "DECRYPTION_ERR") {
                                revealedContentDialogText = "فشل فني: خطأ داخلي فادح في فك تشفير البيانات البنيوية."
                            } else {
                                revealedContentDialogText = plainText
                            }
                            decryptingEntry = null
                            inputDecryptPin = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                ) {
                    Text("عرض المحتوى المفكوك 🔑", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    decryptingEntry = null
                    inputDecryptPin = ""
                }) {
                    Text("إلغاء", color = Color.Gray)
                }
            },
            containerColor = glassCardBg
        )
    }

    if (revealedContentDialogText != null) {
        AlertDialog(
            onDismissRequest = { revealedContentDialogText = null },
            title = { Text("المحتوى السري المعزول 🔑", color = neonGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                val text = revealedContentDialogText ?: ""
                Text(
                    text = text,
                    color = if (text.startsWith("فشل")) neonRed else Color.White,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { revealedContentDialogText = null },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                ) {
                    Text("حسناً", color = Color.Black)
                }
            },
            containerColor = glassCardBg
        )
    }
}
