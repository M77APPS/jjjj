package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun ToolsView(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    var selectedTool by remember { mutableStateOf("menu") } // "menu", "vpn", "terminal", "python", "hardware"

    AnimatedContent(
        targetState = selectedTool,
        transitionSpec = {
            slideInHorizontally { width -> if (targetState == "menu") -width else width } + fadeIn() with
                    slideOutHorizontally { width -> if (targetState == "menu") width else -width } + fadeOut()
        },
        label = "Tools Navigation"
    ) { toolState ->
        when (toolState) {
            "menu" -> ToolsMenu(isAr = isAr, onSelect = { selectedTool = it })
            "vpn" -> SubToolWrapper(title = if (isAr) "تأمين الشبكة والـ VPN" else "Proxy Connection & VPN Core", onBack = { selectedTool = "menu" }) {
                NetworkView(viewModel)
            }
            "terminal" -> SubToolWrapper(title = if (isAr) "طرفية الأوامر حمو" else "Executive Command Line Console", onBack = { selectedTool = "menu" }) {
                TerminalView(viewModel)
            }
            "python" -> SubToolWrapper(title = if (isAr) "مولد سكربتات الحماية" else "Python Cyber Obfuscator", onBack = { selectedTool = "menu" }) {
                SupportView(viewModel)
            }
            "hardware" -> HardwareAuditView(viewModel = viewModel, onBack = { selectedTool = "menu" })
        }
    }
}

@Composable
fun ToolsMenu(isAr: Boolean, onSelect: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                border = BorderStroke(1.dp, CyberSecondary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "⚡ ترسانة الأدوات والمحاكاة" else "⚡ Tactical Armament Grid",
                        color = CyberSecondary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isAr) 
                            "قفل اتصالات الشبكة، محاكاة هجمات الاختراق، توليد أكواد دفاع بايثون معماة." 
                            else "Launch tactical processes, access low-level terminal diagnostics, or construct Python payload sentinel layers.",
                        color = CyberTextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Tools Launchers Grid (as vertical cards)
        item {
            ToolCard(
                title = if (isAr) "بوابة البروكسي و VPN مشفر" else "Encrypted Local VPN & Proxy",
                description = if (isAr) "حجب الإعلانات، تصفية الملقمات الخبيثة، توجيه حركة المرور وتشويه هويتك الرقمية." else "Socks5 encryption, MITM defense mechanisms, DNS spoof mitigation filters.",
                icon = Icons.Default.VpnLock,
                color = CyberPrimary,
                onClick = { onSelect("vpn") }
            )
        }

        item {
            ToolCard(
                title = if (isAr) "محلل الأوامر وطرفية الفحص" else "Hamo Executive Security Console",
                description = if (isAr) "نفذ أوامر الأمان السيبراني مثل 'netstat' و 'sysinfo' ومكافحة التسلل مباشرة." else "Shell environment simulating file system integrity checks, system auditing, and port vulnerability checks.",
                icon = Icons.Default.Terminal,
                color = CyberAccent,
                onClick = { onSelect("terminal") }
            )
        }

        item {
            ToolCard(
                title = if (isAr) "مولد بايثون لصد برمجيات الفدية" else "Python Security Script Obfuscator",
                description = if (isAr) "قم بتوليد وتصدير بايلودات بايثون مصمتة لحراسة خوادمك في بيئات معزولة." else "Export sandboxed python script templates built to prevent ransomware files encryption.",
                icon = Icons.Default.Source,
                color = CyberSecondary,
                onClick = { onSelect("python") }
            )
        }

        item {
            ToolCard(
                title = if (isAr) "حامي العتاد (WiFi, USSD, NFC)" else "Hardware Watchdog & Signalling",
                description = if (isAr) "يفحص شبكات الواي فاي المشبوهة، حظر اتصالات NFC العابرة وتواقيع أكواد USSD الضارة." else "Rogue access-point scanning, ARP cache poisoning scans, and contact-less pay exploit mitigations.",
                icon = Icons.Default.WifiTethering,
                color = CyberError,
                onClick = { onSelect("hardware") }
            )
        }
    }
}

@Composable
fun ToolCard(
    title: String,
    description: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = CyberBgCard),
        border = BorderStroke(0.5.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = RoundedCornerShape(12.dp),
                color = color.copy(alpha = 0.1f),
                border = BorderStroke(1.dp, color.copy(alpha = 0.4f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = CyberTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(text = description, color = CyberTextSecondary, fontSize = 11.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 2.dp))
            }

            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Go", tint = color, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun SubToolWrapper(
    title: String,
    onBack: () -> Unit,
    content: @Composable () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = CyberBgCard),
            border = BorderStroke(0.5.dp, CyberPrimary.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = CyberPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, color = CyberPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
            }
        }
        Box(modifier = Modifier.weight(1f)) {
            content()
        }
    }
}

@Composable
fun HardwareAuditView(viewModel: SecurityViewModel, onBack: () -> Unit) {
    val isAr by viewModel.isArabic.collectAsState()
    var isArpProtectionOn by remember { mutableStateOf(true) }
    var isUssdShieldOn by remember { mutableStateOf(true) }
    var isNfcLockOn by remember { mutableStateOf(true) }

    SubToolWrapper(title = if (isAr) "تحصين عتاد الاتصال والإشارة" else "Hardware & Signaling Enforcer", onBack = onBack) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(0.5.dp, CyberError.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isAr) "📡 فحص ومعايرة الإشارات الخارجية" else "📡 Network & Local Wave Sentinel",
                            color = CyberError,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isAr) 
                                "يحميك هذا القسم من الهجمات من دون ضغط (Zero-Click) مثل محاولات استغلال الواي فاي والبلوتوث ونبضات USSD." 
                                else "Locks down contact-less wave breaches, blocking drive-by OTA payloads and USSD command execution.",
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Wi-Fi evil twin / ARP scan simulation card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(0.5.dp, Color.Gray.copy(0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = if (isAr) "مراقب وإكسارات ARP المحلّية" else "Active ARP Spoofing Defender", color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = if (isAr) "كشف هجومات الرجل في المنتصف للواي فاي" else "Block LAN packet sniffing & MITM routing edits", color = CyberTextSecondary, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isArpProtectionOn,
                                onCheckedChange = { isArpProtectionOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = CyberPrimary)
                            )
                        }
                        
                        Divider(color = Color.Gray.copy(0.1f), modifier = Modifier.padding(vertical = 12.dp))

                        Text(text = if (isAr) "🎯 الشبكات المحيطة المكتشفة:" else "🎯 Surrounding Wave Diagnoses:", color = CyberPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        listOf(
                            Triple("CyberSec_VIP_5G", if (isAr) "مشفرة (آمن جداً)" else "WPA3 Secured (Safe)", CyberTertiary),
                            Triple("Airport_Free_Wifi", if (isAr) "شبكة مفتوحة (خطر - هجمة توأم شرير محتملة!)" else "Evil Twin Signature Flagged! (Extreme Danger)", CyberError),
                            Triple("Home_Router207", if (isAr) "مشفرة (آمن)" else "WPA2 Secured", CyberTertiary)
                        ).forEach { net ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = net.first, color = CyberTextPrimary, fontSize = 11.sp)
                                Text(text = net.second, color = net.third, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // USSD / Call forwarding protection card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(0.5.dp, Color.Gray.copy(0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = if (isAr) "حماية أكواد USSD الإلزامية" else "USSD Command Sanitizer", color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (isAr) 
                                        "منع التطبيقات الخلفية من إطلاق طلبات نقل البيانات أو الأرقام وتصفير الشريحة تلقائياً." 
                                        else "Intercept background attempts to execute MMI/dialer codes that compromise call routing.", 
                                    color = CyberTextSecondary, 
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = isUssdShieldOn,
                                onCheckedChange = { isUssdShieldOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = CyberError)
                            )
                        }

                        if (isUssdShieldOn) {
                            Text(
                                text = if (isAr) "⚡ مرشح الـ USSD نشط ومستعد لحظر الاختراقات." else "⚡ Ready. Safe Dial filter applied to bootloader.",
                                color = CyberTertiary,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 8.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // NFC payment exploit card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberBgCard),
                    border = BorderStroke(0.5.dp, Color.Gray.copy(0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = if (isAr) "درع تشفير صمام NFC القريب" else "Tactical NFC RFID Core", color = CyberTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (isAr) 
                                        "يقفل مستشعرات NFC بالخلفية لصد محاولات مسح البطاقات العشوائية أو هجمات الشحن الزائف." 
                                        else "Prevents contactless signal sniffing by sleep-state sandboxing RFID receivers.", 
                                    color = CyberTextSecondary, 
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = isNfcLockOn,
                                onCheckedChange = { isNfcLockOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = CyberSecondary)
                            )
                        }

                        if (isNfcLockOn) {
                            Text(
                                text = if (isAr) "🔒 صلة الـ NFC مشفرة ومؤصدة بالكامل ضد اللمسات الخبيثة." else "🔒 Contactless antenna isolated to block malicious relay sweeps.",
                                color = CyberSecondary,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 8.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
