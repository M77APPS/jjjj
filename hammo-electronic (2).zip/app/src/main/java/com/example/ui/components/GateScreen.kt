package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel

@Composable
fun GateScreen(viewModel: SecurityViewModel) {
    val context = LocalContext.current
    val isAr by viewModel.isArabic.collectAsState()
    
    // Subscriber states
    val isFb by viewModel.isSubscribedToFacebook.collectAsState()
    val isYt by viewModel.isSubscribedToYoutube.collectAsState()
    val isTg by viewModel.isSubscribedToTelegram.collectAsState()
    
    val allSubscribed = isFb && isYt && isTg

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
    ) {
        // Visual grid background
        CyberpunkGridMesh()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header language selector & shield
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.setArabicLanguage(!isAr) },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = CyberBgCard)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language",
                        tint = CyberPrimary
                    )
                }
                Text(
                    text = if (isAr) "تفعيل بروتوكول حمو" else "HAMO PROTOCOL GATE",
                    color = CyberPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }

            // Central Gating illustration and title
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(140.dp)
                ) {
                    // Floating outer glowing halo
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = CircleShape,
                        color = Color.Transparent,
                        border = BorderStroke(2.dp, if (allSubscribed) CyberTertiary else CyberError.copy(alpha = 0.5f))
                    ) {}
                    
                    // Main high-tech Shield logo from AI generator
                    Card(
                        modifier = Modifier.size(120.dp),
                        shape = CircleShape,
                        border = BorderStroke(1.dp, if (allSubscribed) CyberTertiary else CyberPrimary.copy(alpha = 0.4f))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hamox_icon_1781883448914),
                            contentDescription = "Hamo Cyber Shield Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Floating lock state circle badge
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(36.dp),
                        shape = CircleShape,
                        color = CyberBgCard,
                        border = BorderStroke(1.dp, if (allSubscribed) CyberTertiary else CyberError)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (allSubscribed) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = "Lock Badge State",
                                tint = if (allSubscribed) CyberTertiary else CyberError,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = if (isAr) "بوابة جدار الحماية المشروط" else "Conditional Security Gate",
                    color = CyberTextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = if (isAr) 
                        "برجاء الاشتراك في قنوات حمو الإلكتروني لتفعيل الحماية" 
                        else "Please subscribe to Hamo Electronic channels to activate protection.",
                    color = CyberTextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // FB Portal card
                SubCard(
                    title = if (isAr) "تابع صفحة فيسبوك الرسمية" else "Follow Hamo on Facebook",
                    url = "https://www.facebook.com/profile.php?id=100093514551810",
                    isSubscribed = isFb,
                    onSubClick = {
                        viewModel.subscribeToSocialMedia("facebook")
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/profile.php?id=100093514551810"))
                        context.startActivity(intent)
                    },
                    accentColor = Color(0xFF1877F2),
                    isAr = isAr
                )

                // YT Portal card
                SubCard(
                    title = if (isAr) "اشترك بقناة يوتيوب (Hamoelectronic)" else "Subscribe youtube.com/@hamoelectronic",
                    url = "https://youtube.com/@hamoelectronic",
                    isSubscribed = isYt,
                    onSubClick = {
                        viewModel.subscribeToSocialMedia("youtube")
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic"))
                        context.startActivity(intent)
                    },
                    accentColor = Color(0xFFFF0000),
                    isAr = isAr
                )

                // TG Portal card
                SubCard(
                    title = if (isAr) "انضم لقناة تيليجرام (M77APPS_Support)" else "Join t.me/M77APPS_Support",
                    url = "https://t.me/M77APPS_Support",
                    isSubscribed = isTg,
                    onSubClick = {
                        viewModel.subscribeToSocialMedia("telegram")
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/M77APPS_Support"))
                        context.startActivity(intent)
                    },
                    accentColor = Color(0xFF24A1DE),
                    isAr = isAr
                )
            }

            // Proceed Button
            Button(
                onClick = { 
                    // Gate unlocked by subscription status
                },
                enabled = allSubscribed,
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberTertiary,
                    disabledContainerColor = CyberBgCard
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                border = BorderStroke(1.dp, if (allSubscribed) CyberPrimary else Color.Gray.copy(0.2f))
            ) {
                Text(
                    text = if (isAr) "تنفيذ وتفعيل الحماية ⚡" else "INITIALIZE CORE SHIELD ⚡",
                    color = if (allSubscribed) CyberBg else CyberTextSecondary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SubCard(
    title: String,
    url: String,
    isSubscribed: Boolean,
    onSubClick: () -> Unit,
    accentColor: Color,
    isAr: Boolean
) {
    Surface(
        onClick = onSubClick,
        shape = RoundedCornerShape(12.dp),
        color = CyberBgCard,
        border = BorderStroke(1.dp, if (isSubscribed) CyberTertiary.copy(0.6f) else CyberSecondary.copy(0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(if (isSubscribed) CyberTertiary else accentColor, RoundedCornerShape(5.dp))
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, color = CyberTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = url.substringAfter("https://"), color = CyberTextSecondary, fontSize = 11.sp)
                }
            }
            Icon(
                imageVector = if (isSubscribed) Icons.Default.CheckCircle else Icons.Default.Info,
                contentDescription = "Status",
                tint = if (isSubscribed) CyberTertiary else CyberSecondary
            )
        }
    }
}

@Composable
fun CyberpunkGridMesh() {
    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val step = 80f
        var x = 0f
        while (x < width) {
            drawLine(
                color = Color(0xFF00D4FF).copy(alpha = 0.04f),
                start = androidx.compose.ui.geometry.Offset(x, 0f),
                end = androidx.compose.ui.geometry.Offset(x, height),
                strokeWidth = 1f
            )
            x += step
        }
        var y = 0f
        while (y < height) {
            drawLine(
                color = Color(0xFF9D4EDD).copy(alpha = 0.04f),
                start = androidx.compose.ui.geometry.Offset(0f, y),
                end = androidx.compose.ui.geometry.Offset(width, y),
                strokeWidth = 1f
            )
            y += step
        }
    }
}
