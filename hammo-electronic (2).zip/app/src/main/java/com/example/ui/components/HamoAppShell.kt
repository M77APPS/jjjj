package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.SecurityViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HamoAppShell(viewModel: SecurityViewModel) {
    val isAr by viewModel.isArabic.collectAsState()
    val isEmergencyActive by viewModel.isEmergencyModeActive.collectAsState()
    val isSilentShieldOn by viewModel.isSilentShieldActive.collectAsState()

    var activeScreen by remember { mutableStateOf("dashboard") }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // Slide Drawer navigation list
    val menuItems = listOf(
        Triple("dashboard", if (isAr) "الرئيسية والعداد" else "Dashboard Core", Icons.Default.Dashboard),
        Triple("protection", if (isAr) "حاجز حماية التجسس" else "Spyware & Protection", Icons.Default.Security),
        Triple("vault", if (isAr) "الخزنة المشفرة AES" else "Encrypted Vault", Icons.Default.Lock),
        Triple("tools", if (isAr) "لوحة الأدوات والعتاد" else "Tools Arsenal", Icons.Default.Build),
        Triple("settings", if (isAr) "إعدادات بروتوكول حمو" else "System Settings", Icons.Default.Settings)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CyberBgCard,
                modifier = Modifier.width(300.dp)
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                // Profile header banner
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "⚡ حمو الإلكتروني",
                        color = CyberPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Hamo Cyber Armored v1.4",
                        color = CyberTextSecondary,
                        fontSize = 11.sp
                    )
                }

                Divider(color = Color.Gray.copy(0.1f), modifier = Modifier.padding(vertical = 12.dp))

                menuItems.forEach { item ->
                    NavigationDrawerItem(
                        label = { Text(text = item.second, color = if (activeScreen == item.first) CyberPrimary else CyberTextPrimary) },
                        selected = activeScreen == item.first,
                        onClick = {
                            activeScreen = item.first
                            coroutineScope.launch { drawerState.close() }
                        },
                        icon = { Icon(imageVector = item.third, contentDescription = item.second, tint = if (activeScreen == item.first) CyberPrimary else Color.Gray) },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CyberPrimary.copy(0.08f),
                            unselectedContainerColor = Color.Transparent
                        )
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Language toggle in bottom of drawer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "اللغة العربية", color = CyberTextPrimary, fontSize = 13.sp)
                    Switch(
                        checked = isAr,
                        onCheckedChange = { viewModel.setArabicLanguage(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = CyberPrimary)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = if (isAr) "الدرع النهائي 2027 🛡️" else "ULTIMATE SHIELD 2027 🛡️",
                            color = CyberPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu", tint = CyberPrimary)
                        }
                    },
                    actions = {
                        // Silent Shield dynamic blink indicator
                        IconButton(onClick = { viewModel.isSilentShieldActive.value = !isSilentShieldOn }) {
                            Icon(
                                imageVector = if (isSilentShieldOn) Icons.Default.Shield else Icons.Default.ShieldMoon,
                                contentDescription = "Silent Shield",
                                tint = if (isSilentShieldOn) CyberTertiary else Color.Gray
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = CyberBg
                    )
                )
            },
            floatingActionButton = {
                // Emergency EMP Bypass switch Button
                FloatingActionButton(
                    onClick = {
                        if (isEmergencyActive) {
                            viewModel.disableEmergencyMode()
                        } else {
                            viewModel.triggerEmergencyMode()
                        }
                    },
                    containerColor = if (isEmergencyActive) CyberTertiary else CyberError,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = if (isEmergencyActive) Icons.Default.GppGood else Icons.Default.LockReset,
                        contentDescription = "Emergency Lockdown",
                        tint = CyberBg
                    )
                }
            },
            bottomBar = {
                // Customized navigation rail bar for quick transitions
                NavigationBar(
                    containerColor = CyberBgCard,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = activeScreen == "dashboard",
                        onClick = { activeScreen = "dashboard" },
                        icon = { Icon(imageVector = Icons.Default.Dashboard, contentDescription = "Dashboard") },
                        label = { Text(text = if (isAr) "الرئيسية" else "Dashboard", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary.copy(0.08f)
                        )
                    )

                    NavigationBarItem(
                        selected = activeScreen == "protection",
                        onClick = { activeScreen = "protection" },
                        icon = { Icon(imageVector = Icons.Default.Security, contentDescription = "Protection") },
                        label = { Text(text = if (isAr) "الحماية" else "Protection", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary.copy(0.08f)
                        )
                    )

                    NavigationBarItem(
                        selected = activeScreen == "vault",
                        onClick = { activeScreen = "vault" },
                        icon = { Icon(imageVector = Icons.Default.Lock, contentDescription = "Vault") },
                        label = { Text(text = if (isAr) "الخزنة" else "Vault", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary.copy(0.08f)
                        )
                    )

                    NavigationBarItem(
                        selected = activeScreen == "tools",
                        onClick = { activeScreen = "tools" },
                        icon = { Icon(imageVector = Icons.Default.Build, contentDescription = "Tools") },
                        label = { Text(text = if (isAr) "الأدوات" else "Tools", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary.copy(0.08f)
                        )
                    )

                    NavigationBarItem(
                        selected = activeScreen == "settings",
                        onClick = { activeScreen = "settings" },
                        icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text(text = if (isAr) "الإعدادات" else "Settings", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary.copy(0.08f)
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(CyberBg)
            ) {
                // Emergency Lockdown overlay
                if (isEmergencyActive) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(CyberError.copy(0.15f))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CyberTerminalBg),
                            border = BorderStroke(1.dp, CyberError),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GppBad,
                                    contentDescription = "EMP active",
                                    tint = CyberError,
                                    modifier = Modifier.size(56.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (isAr) "⚠️ وضع قفل الطوارئ التام نشط!" else "⚠️ ZERO-TRUST LOCKDOWN MANDATE ACTIVE",
                                    color = CyberError,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = if (isAr)
                                        "تم قطع اتصال البروكسي وبوابات الواي فاي تلقائياً لمنع خروج الحزم المشبوهة. الهاتف محمي كلياً."
                                        else "Outbound packet gates dropped. Wifi adapters sandboxed. Unauthenticated sensors locked to prevent telemetry leaks.",
                                    color = CyberTextSecondary,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = { viewModel.disableEmergencyMode() },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberTertiary)
                                ) {
                                    Text(text = if (isAr) "إلغاء وضع الطوارئ والتشغيل" else "Re-authorize Network Core", color = CyberBg, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    // Module Views Controller
                    when (activeScreen) {
                        "dashboard" -> DashboardView(viewModel, onSelectMenu = { activeScreen = it })
                        "protection" -> SpywareView(viewModel)
                        "vault" -> LockerView(viewModel)
                        "tools" -> ToolsView(viewModel)
                        "settings" -> SettingsView(viewModel)
                        else -> DashboardView(viewModel, onSelectMenu = { activeScreen = it })
                    }
                }
            }
        }
    }
}
